#NEW NEW NEW 4 nested channels 
# 
#A nested dictionary for an experiment. An experiment consists of 
# - metadata comment timestamp,
# - scope settings, 
# - AWG settings
# - data and 
import json                      #dump dictionary to file
expedict={}
expedict.update({"time":"timestamp"})
expedict.update({"cmnt":"commentaar"})
scopdict={}
scopdict.update({"*idn":"ident"})

timedict={}
timedict.update({"scal":":TIM:SCAL?"})
timedict.update({"offs":":TIM:OFFS?"})
timedict.update({"href":":TIM:HREF:MODE TRIG"})  #NEW

trigdict={}
trigdict.update({"mode":":TRIG:MODE?"})
trigdict.update({"sour":":TRIG:EDGE:SOUR?"})
trigdict.update({"slop":":TRIG:EDGE:SLOP?"})
trigdict.update({"leve": ":TRIG:EDGE:LEV?"})
trigdict.update({"hold":":TRIG:HOLD?"})

cha1dict={}
cha1dict.update({'disp':":CHAN1:DISP?"})
cha1dict.update({'scal':":CHAN1:SCAL?"})
cha1dict.update({'offs':":CHAN1:OFFS?"})
cha2dict={}
cha2dict.update({'disp':":CHAN2:DISP?"})
cha2dict.update({'scal':":CHAN2:SCAL?"})
cha2dict.update({'offs':":CHAN2:OFFS?"})
cha3dict={}
cha3dict.update({'disp':":CHAN3:DISP?"})
cha3dict.update({'scal':":CHAN3:SCAL?"})
cha3dict.update({'offs':":CHAN3:OFFS?"})
cha4dict={}
cha4dict.update({'disp':":CHAN4:DISP?"})
cha4dict.update({'scal':":CHAN4:SCAL?"})
cha4dict.update({'offs':":CHAN4:OFFS?"})

chaxdict={}
chaxdict["1"]=cha1dict
chaxdict["2"]=cha2dict
chaxdict["3"]=cha3dict
chaxdict["4"]=cha4dict

wavedict={}
wavedict.update({'sour':":WAV:SOUR CHAN1"})
wavedict.update({'form':":WAV:FORM ASC"})
wavedict.update({'mode':":WAV:MODE NORM"})
#with settings
scopdict["time"] = timedict
scopdict["trig"] = trigdict
scopdict["chan"] = chaxdict
scopdict["wave"] = wavedict
sourdict={}                       
sourdict.update({'stat':":SOUR:OUTP:STAT"})
sourdict.update({'func':":SOUR:FUNC"})
sourdict.update({'freq':":SOUR:FREQ"})
sourdict.update({'volt':":SOUR:VOLT:AMPL"})
sourdict.update({'offs':":SOUR:VOLT:OFFS"})

datadict={}
datadict.update({'Vin':-1})
datadict.update({'Rcal':100})
datadict.update({'chan':1})
datadict.update({'data':[123]})

expedict["scop"] = scopdict
expedict["sour"] = sourdict
expedict["data"] = datadict

def dump_settings_to_json(file_path):
    with open(file_path, 'w') as f:
        json.dump(expedict, f)

def print_nested_keys(dictionary, indent=0):
    for key, value in dictionary.items():
        print("  " * indent + str(key))
        if isinstance(value, dict):
            print_nested_keys(value, indent + 1)

if __name__ == "__main__":
#    print(expedict)
    print_nested_keys(expedict,2)
    #print(json.dumps(expedict,sort_keys=False, indent=4))
