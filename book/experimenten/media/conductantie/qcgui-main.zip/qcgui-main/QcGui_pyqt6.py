import warnings  # kill sip depreciation warning
import sys
import os
import traceback  # for error an exception handling
import serial  # for arduino
import serial.tools.list_ports
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from MatplotlibDisplayWidget import dataDisplayWidget, speakerDisplayWidget, levelsDisplayWidget
from PyQt6.QtWidgets import QApplication, QMainWindow, QHBoxLayout, \
    QVBoxLayout, QPushButton, QWidget, QLineEdit, QLabel, \
     QFormLayout, QSlider, QTextEdit, QFileDialog, QDialog, \
    QMessageBox, QDialogButtonBox
from PyQt6.QtGui import QAction
from qtrangeslider import QRangeSlider  # install with pip install qtrangeslider https://pypi.org/project/QtRangeSlider/
from PyQt6 import QtCore as qtc
from PyQt6 import QtGui as qtg
from PyQt6.QtCore import QTimer
from datetime import datetime
from time import sleep
import random
from scope import Scope  # from current dir
# from TextDisplayWidgetSQL import TextDisplayWidget as tdw   #from current dir
from htmlDisplaywidget import HtmlDisplayWidget as hdw  # from current dir
from quantumconductance import expedict  # from current dir
import json  # dump dictionary to file


# --------------------------------------------------------
# vorige versie chatgptarduinomatplotlib_try_textdisplaywidget.py
# suppress DeprecationWarning: sipPyTypeDict() is deprecated, the extension module should use sipPyTypeDictRef() instead
# warnings.simplefilter(action='ignore', category=DeprecationWarning)

class PopupWindow(QDialog):
    '''preserves current text'''

    def __init__(self, parent=None, initial_text=""):
        super().__init__(parent)
        self.setWindowTitle("Edit comment")
        self.setGeometry(200, 200, 300, 200)

        self.text_edit = QTextEdit(self)
        self.text_edit.setText(initial_text)  # Set the initial text

        # Move cursor to the end of the text
        cursor = self.text_edit.textCursor()
        cursor.movePosition(qtg.QTextCursor.MoveOperation.End)
        self.text_edit.setTextCursor(cursor)

        submit_button = QPushButton("Submit", self)
        submit_button.clicked.connect(self.submit_text)

        layout = QVBoxLayout()
        layout.addWidget(self.text_edit)
        layout.addWidget(submit_button)
        self.setLayout(layout)

    def submit_text(self):
        text = self.text_edit.toPlainText()
        if self.parent():
            self.parent().process_text(text)
        self.close()


class Dialogwindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.resize(640, 480)
        self.message_a_edit = QLineEdit()
        self.message_a_edit.setReadOnly(True)
        infotext = QLabel('Maak kortsluiting door de bladveer naar voren te duwen. ' + \
                          'Je kunt Uin aflezen op de oscilloscoop. Stel met je andere ' + \
                          'hand Uin (grote knop) zodat 190 < Uin < 210 mV is. ' + \
                          'Druk dan op measure', wordWrap=True, font=qtg.QFont('Sans', 12))
        self.cancel_button = QPushButton('Cancel')
        self.measureVin_button = QPushButton('Measure Uin')
        self.submit_button = QPushButton('Submit')
        self.setLayout(QFormLayout())
        self.layout().addRow('Uin', self.message_a_edit)
        buttons = QWidget()
        buttons.setLayout(QHBoxLayout())
        buttons.layout().addWidget(self.cancel_button)
        buttons.layout().addWidget(self.measureVin_button)
        buttons.layout().addWidget(self.submit_button)
        self.layout().addRow('', buttons)
        self.layout().addRow(infotext)
        self.submit_button.setEnabled(False)
        self.submit_button.clicked.connect(self.on_submit)
        self.measureVin_button.clicked.connect(self.on_measureVin)
        # measureVin_button.clicked.connect(self.update_number_in_parent)
        self.cancel_button.clicked.connect(self.close)

        # stel vertikaal schaal van channel 1 & 2, set chan1 active
        self.parent().sc.write(":CHAN2:DISP 1")
        self.parent().sc.write(":CHAN1:DISP 1");  # ch1 now active
        self.parent().sc.write(":CHAN2:SCAL 0.5")
        self.parent().sc.write(":CHAN1:SCAL 0.1")
        # start meting Uin
        self.parent().sc.write(":MEAS:ITEM VAVG,CHAN1")
        # self.parent().Vin = '0.123'

    def on_measureVin(self):
        self.vin = float(self.parent().sc.query(":MEAS:ITEM? VAVG,CHAN1"))
        print(f"vin={self.vin}")
        self.message_a_edit.setText(str(self.vin))
        if self.vin < 0.210 and self.vin > 0.190:
            self.submit_button.setEnabled(True)
            print(F'Vin={self.vin}')

    def set_message(self, message_a):
        self.message_a_edit.setText(message_a)

    def on_submit(self):
        self.parent().sc.write(":MEAS:CLE")
        if isinstance(self.parent(), ArduinoGraphApp):
            self.parent().Vin = self.vin
            self.parent().Vin_measured = True
        #            print("Updated Vin ParentWindow:", self.parent().Vin)
        self.close()

    def update_number_in_parent(self):
        new_value = 42  # Example value
        if isinstance(self.parent(), ArduinoGraphApp):
            self.parent().number = new_value
            print("Updated number in ParentWindow:", self.parent().number)


class ArduinoGraphApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ed = expedict  #
        self.swversion = "V1.12"
        self.ed["cmnt"] = "software version: " + self.swversion
        self.stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.ed["time"] = self.stamp
        self.ed["data"]["Rcal"] = 100.0  # later in settings file?
        self.sc = Scope()
        self.init_states()
        self.sc.connect()
        self.olddata = False  # data from file logic tbd
        if self.sc.connected:
            self.ed["scop"]["*idn"] = self.sc.id().split(",")[1]
        self.initUI()

        if False:  # adruino connected
            # Initialize serial communication with your Arduino (adjust the port)
            sc = SerCom()
            sc.testfind()
            sc.find_arduino()
            self.statusBar().showMessage(sc.ser.port + " " + str(sc.ser.baudrate), 2000)

            print(">> >>" + sc.ser.port + " " + str(sc.ser.baudrate))

        #        self.ser = serial.Serial('COM3', baudrate=115200)
        # Initialize data arrays
        self.coords: list = []
        self.multiplot = False  # plot all traces

    def init_states(self):
        '''variables that define the state of this app
        device connected, Vin measured, file from disk,reset
        '''
        self.sc.connected = False
        self.Vin_measured: bool = False
        self.plothisto: bool = False
        self.dataindex: int = 0
        self.alldata: list = []

    def initUI(self):
        self.setWindowTitle("Quantum Conductance")
        self.setGeometry(50, 50, 1800, 900)
        self.init_menu()

        self.central_widget = QWidget(self)
        #        self.layout = QVBoxLayout(self.central_widget)
        self.init_figs()

        # Create a label for displaying mouse coordinates
        self.coord_label = QLabel('', self.central_widget, font=qtg.QFont('Sans', 12))
        self.coord_label.setGeometry(qtc.QRect(1000, 490, 250, 144))
        self.coord_label.setWordWrap(True)
        self.coord_label.setStyleSheet("background-color: rgb(217, 245, 199);")

        # Connect the mouse move event to the function
        self.mplfig.canvas.mpl_connect('motion_notify_event', self.on_mouse_move)
        self.mplfig.canvas.mpl_connect('button_press_event', self.on_mouse_click)

        self.init_buttons()
        self.init_sliders()

        if self.sc.connected:
            self.statusBar().showMessage("scope connected: " + self.ed["scop"]["*idn"], 2000)
        else:
            self.statusBar().showMessage('connect scope', 2000)

        self.Vin_label = QLabel("U_in = : ", self.central_widget)
        self.Vin_label.setStyleSheet("background-color: rgb(247, 255, 199);")
        self.Vin_label.setGeometry(qtc.QRect(800, 540, 191, 22))

        self.Rcal_label = QLabel("Rcal: " + str(self.ed["data"]["Rcal"]) + " Ohm", self.central_widget)
        self.Rcal_label.setStyleSheet("background-color: rgb(247, 255, 199);")
        self.Rcal_label.setGeometry(qtc.QRect(800, 570, 191, 22))

        self.comment_label = QLabel(self.ed["cmnt"], self.central_widget)
        self.comment_label.setStyleSheet("background-color: rgb(247, 255, 199);")
        self.comment_label.setWordWrap(True)
        self.comment_label.setAlignment(qtc.Qt.AlignTop)
        self.comment_label.setGeometry(qtc.QRect(800, 620, 191, 140))

        self.term_input = QLineEdit('call', self.central_widget)
        self.term_input.setGeometry(qtc.QRect(800, 770, 191, 22))
        self.term_input.editingFinished.connect(self.get_answer)

        self.ident_label = QLabel("no connection", self.central_widget)
        self.ident_label.setStyleSheet("background-color: rgb(247, 255, 199);")
        self.ident_label.setWordWrap(True)
        self.ident_label.setAlignment(qtc.Qt.AlignTop)
        self.ident_label.setGeometry(qtc.QRect(800, 700, 191, 140))

        if (self.sc.connected):
            self.start_func_button.setEnabled(True)
            self.measure_vin_button.setEnabled(True)
            self.state2_button.setEnabled(True)
            self.ident_label.setText(f'connected to {self.ed["scop"]["*idn"]}')
            print(f'connected to {self.ed["scop"]["*idn"]}')
        else:
            self.start_func_button.setEnabled(False)
            self.measure_vin_button.setEnabled(False)
            self.state2_button.setEnabled(False)
            self.ident_label.setText(f'not connected')

        # statusbar
        #        self.statusBar().showMessage('Welcome',2000)
        self.setCentralWidget(self.central_widget)

    def init_figs(self):
        self.text_display = hdw(self.central_widget)
        self.text_display.setGeometry(qtc.QRect(10, 10, 880, 480))

        self.mplfig = dataDisplayWidget(self.central_widget)
        self.mplfig.setStyleSheet("background-color: rgb(217, 255, 199);")
        self.mplfig.setGeometry(qtc.QRect(900, 10, 880, 480))
        self.mplfig.control_buttons.setVisible(False)
        self.mplfig.button_pressed.connect(self.handle_button_pressed)
        #        self.mplfig.ax.set_title('data')

        self.speakersignalfig = speakerDisplayWidget(self.central_widget)
        self.speakersignalfig.setStyleSheet("background-color: rgb(217, 255, 19);")
        self.speakersignalfig.setGeometry(qtc.QRect(150, 510, 280, 280))
        self.speakersignalfig.control_buttons.setVisible(False)
        self.speakersignalfig.ax.set_title('speaker')

        self.levelsfig = levelsDisplayWidget(self.central_widget)
        self.levelsfig.setStyleSheet("background-color: rgb(217, 255, 19);")
        self.levelsfig.setGeometry(qtc.QRect(450, 510, 280, 280))
        self.levelsfig.control_buttons.setVisible(False)
        self.levelsfig.ax.set_title('fit coordinates')

    def init_buttons(self):
        self.layoutWidget = QWidget(self.central_widget)
        self.layoutWidget.setStyleSheet("background-color: rgb(197, 255, 199);")
        self.layoutWidget.setGeometry(qtc.QRect(10, 510, 102, 300))  # knoppenbox
        self.layoutWidget.setObjectName("layoutWidget")
        self.formLayout = QFormLayout(self.layoutWidget)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setObjectName("formLayout")

        self.state1_button = QPushButton("reset scope", self.layoutWidget)
        self.state1_button.setObjectName("state1Button")
        self.formLayout.setWidget(0,  QFormLayout.ItemRole.LabelRole, self.state1_button)
        self.state1_button.clicked.connect(self.resetScope)

        self.state2_button = QPushButton("nu jij", self.layoutWidget)
        self.state2_button.setObjectName("nujijButton")
        self.formLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.state2_button)
        self.state2_button.clicked.connect(self.nujij)

        self.state3_button = QPushButton("Edit comment", self.layoutWidget)
        self.state3_button.setObjectName("commentButton")
        self.formLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.state3_button)
        self.state3_button.clicked.connect(self.edit_Comment)

        self.multi_button = QPushButton("Single trace", self.layoutWidget)
        self.multi_button.setObjectName("MultiButton")
        self.formLayout.setWidget(3, QFormLayout.ItemRole.LabelRole, self.multi_button)
        self.multi_button.clicked.connect(self.single_trace)

        self.measure_vin_button = QPushButton("Vin meten", self.layoutWidget)
        self.measure_vin_button.setObjectName("startFun")
        self.formLayout.setWidget(4, QFormLayout.ItemRole.LabelRole, self.measure_vin_button)
        self.measure_vin_button.clicked.connect(self.measure_vin)

        self.start_func_button = QPushButton("Start func", self.layoutWidget)
        self.start_func_button.setObjectName("startFunc")
        self.formLayout.setWidget(5, QFormLayout.ItemRole.LabelRole, self.start_func_button)
        self.start_func_button.clicked.connect(self.start_func)

        self.clear_coords_button = QPushButton("Clear points", self.layoutWidget)
        self.clear_coords_button.setObjectName("Clearpoints")
        self.formLayout.setWidget(6, QFormLayout.ItemRole.LabelRole, self.clear_coords_button)
        self.clear_coords_button.clicked.connect(self.clear_coords)

        self.plot_coords_button = QPushButton("Plot points", self.layoutWidget)
        self.plot_coords_button.setObjectName("Plotpoints")
        self.formLayout.setWidget(7, QFormLayout.ItemRole.LabelRole, self.plot_coords_button)
        self.plot_coords_button.clicked.connect(self.plot_coords)

        self.test_scope_button = QPushButton("test scope", self.layoutWidget)
        self.test_scope_button.setObjectName("testScope")
        self.formLayout.setWidget(8, QFormLayout.ItemRole.LabelRole, self.test_scope_button)
        self.test_scope_button.clicked.connect(self.test_scope)

        self.prev_data_button = QPushButton("prev Data", self.layoutWidget)
        self.prev_data_button.setObjectName("prevdata")
        self.formLayout.setWidget(9, QFormLayout.ItemRole.LabelRole, self.prev_data_button)
        self.prev_data_button.clicked.connect(self.prev_data)

        self.next_data_button = QPushButton("next Data", self.layoutWidget)
        self.next_data_button.setObjectName("nexdata")
        self.formLayout.setWidget(10, QFormLayout.ItemRole.LabelRole, self.next_data_button)
        self.next_data_button.clicked.connect(self.next_data)

        # self.histogram_button = QPushButton("histogram on", self.layoutWidget)
        # self.histogram_button.setObjectName("nexdata")
        # self.formLayout.setWidget(11, QFormLayout.ItemRole.LabelRole, self.histogram_button)
        # self.histogram_button.clicked.connect(self.plothistogram)

    def init_menu(self):
        # Create a menu bar
        menubar = self.menuBar()
        # File menu
        fileMenu = menubar.addMenu('&File')
        # New action
        newAction = QAction('&New', self)
        newAction.setShortcut('Ctrl+N')
        newAction.triggered.connect(self.newFile)
        fileMenu.addAction(newAction)

        # Open action
        openAction = QAction('&Open', self)
        openAction.setShortcut('Ctrl+O')
        openAction.triggered.connect(self.openFile)
        fileMenu.addAction(openAction)

        # Separator
        fileMenu.addSeparator()

        # Save action
        saveAction = QAction('&Save', self)
        saveAction.setShortcut('Ctrl+S')
        saveAction.triggered.connect(self.saveFile)
        fileMenu.addAction(saveAction)

        # Save As action
        saveAsAction = QAction('&Save As', self)
        saveAsAction.triggered.connect(self.saveAsFile)
        fileMenu.addAction(saveAsAction)

        # Separator
        fileMenu.addSeparator()

        # Close action
        closeAction = QAction('&Close', self)
        closeAction.setShortcut('Ctrl+W')
        fileMenu.addAction(closeAction)

        # Exit action
        exitAction = QAction('&Exit', self)
        exitAction.setShortcut('Ctrl+Q')
        exitAction.setStatusTip('Exit application')
        exitAction.triggered.connect(self.close)
        fileMenu.addAction(exitAction)
        # Edit menu
        editMenu = menubar.addMenu('&Edit')
        editCommentAction = QAction('&Comment', self)
        editCommentAction.setStatusTip('edit comment')
        editCommentAction.triggered.connect(self.edit_Comment)
        editMenu.addAction(editCommentAction)
        # View menu
        viewMenu = menubar.addMenu('&View')

        self.viewHistogamAction = QAction('Show &Histogram', self)
        self.viewHistogamAction.setStatusTip('toggle histogram')
        self.viewHistogamAction.setCheckable(True)  # Make it checkable
        self.viewHistogamAction.setChecked(False)  # Set initial checked state
        self.viewHistogamAction.triggered.connect(self.plothistogram)
        viewMenu.addAction(self.viewHistogamAction)
        # Help menu
        helpMenu = menubar.addMenu('&Help')
        # About action
        aboutAction = QAction('&About', self)
        aboutAction.setStatusTip('about his software')
        aboutAction.triggered.connect(self.aboutHelp)
        helpMenu.addAction(aboutAction)

    def init_sliders(self):
        self.qrange_slider = QRangeSlider(self.central_widget)
        self.qrange_slider.setGeometry(qtc.QRect(120, 510, 20, 280))
        self.qrange_slider.setOrientation(qtc.Qt.Vertical)
        self.qrange_slider.setBarIsRigid(False)
        self.qrange_slider.setObjectName("verticalSlider")
        self.qrange_slider.setMinimum(0)
        self.qrange_slider.setMaximum(1000)
        self.qrange_slider.setSingleStep(1)
        self.qrange_slider.setPageStep(10)
        self.qrange_slider.setValue((100, 900))
        self.qrange_slider.valueChanged.connect(self.update_speaker)

        self.horizontalSlider = QSlider(self.central_widget)
        self.horizontalSlider.setGeometry(qtc.QRect(170, 800, 250, 22))
        self.horizontalSlider.setOrientation(qtc.Qt.Horizontal)
        self.horizontalSlider.setMinimum(1)  # only accepts positive ints??
        self.horizontalSlider.setMaximum(300)
        self.horizontalSlider.setSingleStep(1)
        self.horizontalSlider.setPageStep(10)
        self.horizontalSlider.setValue(300)
        self.horizontalSlider.setObjectName("horizontalSlider")
        self.horizontalSlider.valueChanged.connect(self.update_speaker)
        self.freq = self.horizontalSlider.value() / 10.

    def edit_Comment(self):
        current_comment = self.comment_label.text()  # Get the current comment
        popup = PopupWindow(parent=self, initial_text=current_comment)  # Pass the current comment
        popup.exec()

    def process_text(self, text):
        print("Text received from popup:", text)
        self.comment_label.setText(text)

    def resetScope(self):
        self.text_display.jump_to_page(3)
        # self.sc.write("*RST")

    def nujij(self):
        # we zetten de scoop klaar
        self.text_display.jump_to_page(4)
        self.sc.write(":TRIGger:EDGE:SOURce CHAN1")
        self.sc.write(":TRIGger:COUP DC")
        self.sc.write(":TRIGger:EDGE:SLOP NEG")
        self.sc.write(":TRIGger:EDGE:LEVel 0.01")
        self.sc.write(":TRIGger:SWE NORM")
        self.sc.write(":TRIGger:HOLDoff " + str(np.ceil(100 / self.freq) / 200))
        # print(1/freq.value,str(np.ceil(100/freq.value)/200))

    def on_todo(self):
        QMessageBox.about(self, 'on_todo', "dat moet nog gemaakt")

    def on_mouse_move(self, event):
        # Get mouse coordinates and convert to figure coordinates
        if event.inaxes:
            x, y = event.xdata, event.ydata
            self.coord_label.setText(f'x={x:.2e}, y={y:.2e}')
        else:
            self.coord_label.setText('')

    def on_mouse_click(self, event):
        # Get mouse coordinates and convert to figure coordinates
        if event.inaxes:
            x, y = event.xdata, event.ydata
            self.coord_label.setText(f'Mouse clicked at: x={x:.2e}, y={y:.2e}')
            self.coords.append((x, y))
            # connected to the *second* axis in the plot (histogram) so plot also in this ax
            self.mplfig.ax_plot.scatter(list(zip(*self.coords))[0], list(zip(*self.coords))[1], c='r', linestyle='-')
            self.mplfig.canvas.draw()
        else:
            self.coord_label.setText('')

    def clear_coords(self):
        # clears coordinates and redraws graph
        self.coords = []
        self.plot_coords()
        self.redraw_graph()

    def start_func(self):
        self.start_func_button.setText("stop func")
        self.start_func_button.clicked.connect(self.stop_func)
        # clears coordinates and redraws graph (?)
        # preset scope for the experiment
        self.sc.write(":SOURce:FUNC SIN")
        self.sc.write(":SOURce:VOLT:AMPL 0.3")
        self.sc.write(":SOURce:VOLT:OFFS 0")
        self.sc.write(":SOURce:FREQ 30")
        self.sc.write(":SOURce:OUTP:STAT 1")
        # speak.write(":SOURce:OUTPut:STATe OFF") #AWG off
        self.sc.write(":CHAN2:DISP 1")
        self.sc.write(":CHAN2:SCAL 0.1")
        self.sc.write(":CHAN2:OFFS 0.0")
        # last channel set is active on front panel
        self.sc.write(":CHAN1:DISP 1")
        self.sc.write(":CHAN1:SCAL 0.1")
        self.sc.write(":CHAN1:OFFS 0.0")

        # slow time scale
        # 0.05 -> roll mode
        self.sc.write(":TIM:SCAL 0.01")

        # trigger
        self.sc.write(":TRIG:HOLD 0.001")
        # scope.write(":TRIG:LEV 0.0")
        # float(scope.query(":TRIG:HOLD?"))
        # trigger op blauw auto AC
        self.sc.write(":TRIGger:EDGE:SOURce CHANnel2")
        self.sc.write(":TRIGger:COUPling AC")
        self.sc.write(":TRIGger:EDGE:SLOPe NEG")  # trigger on negative slope
        self.statusBar().showMessage(f'start function generator', 2000)
        # set timing reference to screen coordinate
        self.sc.write(":TIM:HREF:MODE TRIG")
        self.update_speaker()

    def stop_func(self):
        self.sc.write(":SOURce:OUTP:STAT 0")
        self.start_func_button.setText("start func")
        self.start_func_button.clicked.connect(self.start_func)

    def measure_vin(self, Vin):
        # moet alleen bereikbaar zijn als self.connected
        self.statusBar().showMessage(f'measure vin', 2000)  # waarom diet ie dat niet?
        if self.sc.connected:
            self.text_display.jump_to_page(5)
            dialog = Dialogwindow(parent=self)
            dialog.exec()
            if self.Vin_measured:
                self.Vin_label.setText('U_in = ' + str(1000 * self.Vin) + ' mV')
                self.ed['data']['Vin'] = self.Vin
                print(f'done Vin{self.ed["data"]["Vin"]}')
            else:
                print(f'Vin not set{self.Vin_measured}')
        elif self.olddata:  # niet hier
            self.Vin = str(self.ed['data']['Vin'])
            print('vin=', self.Vin)
            self.Vin_label.setText(self.Vin)

    def test_scope(self):
        # clears coordinates and redraws graph
        #        self.sc.write(":SOURce:FUNC SIN")
        #        self.statusBar().showMessage(f'scope function')
        self.text_display.jump_to_page(4)

    def update_speaker(self):
        mi, ma = self.qrange_slider.value()
        mo = self.horizontalSlider.value()  # freq
        mi = (mi - 500.) / 4000.  # recalculate amplitude and offset
        ma = (ma - 500.) / 4000.  # scope wants peakpeak values
        self.statusBar().showMessage(f'speaker changed: {mi}, {ma} freq: {mo}')
        self.freq = mo / 10.
        offs = (mi + ma) / 2.
        amp = (ma - mi)
        amplmin = -0.25  # should be defined better
        amplmax = 0.25
        try:
            self.sc.write(":SOUR:VOLT:AMPL " + str(amp))
            self.sc.write(":SOUR:VOLT:OFFS " + str(offs))
            self.sc.write(":SOUR:FREQ " + str(self.freq))
            print(f'sc.write amp= {amp}, offs= {offs}, freq= {self.freq}')
        except:
            print("VisaIOError")
        xt = np.linspace(-1, 1, 1000)
        self.speakersignalfig.ax.clear()
        y = [offs + amp * np.cos(2 * np.pi * (self.freq * a)) for a in xt]
        self.speakersignalfig.ax.plot(xt, y)
        self.speakersignalfig.ax.set_ylim([amplmin, amplmax])
        self.speakersignalfig.ax.set_xlim([-0.1, 0.1])
        self.speakersignalfig.canvas.draw()

    def plot_coords(self):
        if self.coords == []:
            self.levelsfig.ax.clear()
            self.levelsfig.canvas.draw()
        else:
            try:
                ytops = sorted(np.array(self.coords).T[1])
                xtops = np.arange(0, len(ytops))  # just a ranking
                self.levelsfig.ax.clear()
                self.levelsfig.ax.plot(xtops, ytops, 'o')
                model = np.polyfit(xtops, ytops, 1)  # fit 1e graads polynoom(=rechte lijn)
                predict = np.poly1d(model)
                yfit = predict(xtops)
                self.levelsfig.ax.plot(xtops, yfit, '-')
                self.levelsfig.canvas.draw()
                self.levelsfig.ax.text(0.5, 0.9, "y={:0.2e}+{:0.2e}".format(model[0], model[1]),
                                       horizontalalignment='center',
                                       verticalalignment='center',
                                       transform=self.levelsfig.ax.transAxes)
                self.levelsfig.ax.set(xlabel='maximum nr', ylabel='spanning (V)')
                if self.Vin_measured:
                    msg = "Tada! Uit dit experiment volgt een quantumweerstand: {:0.3e} Ohm" \
                        .format(100 * (self.ed['data']['Vin'] - model[0]) / model[0])
                    QMessageBox.about(self, 'Done that', msg)

                    print(msg)
                else:
                    print("eerst nog vin meten")
                    self.statusBar().showMessage("eerst nog vin meten")
            except Exception as err:
                # handle the exception
                msg = type(err).__name__
                self.statusBar().showMessage(msg)
                msg = ''.join(traceback.TracebackException.from_exception(err).format())
                print(msg)

    def get_answer(self):
        #    term = self.term_input.text()
        #    print(">>>>", term, "<<<<")
        #    ans=.tellme(int(term))
        #    print(ans)
        #    self.label.setText(ans)
        # self.nb=self.sc.readtrace()
        term = self.term_input.text()
        self.statusBar().showMessage(term)

    def handle_button_pressed(self, direction):
        if direction == "prev":
            # Handle previous button press
            print("Previous button pressed")
            if self.dataindex > 0:
                self.dataindex -= 1
                self.update_graph()

        elif direction == "next":
            # Handle next button press
            print("Next button pressed")
            if self.dataindex < len(self.alldata) - 1:
                self.dataindex += 1
                self.update_graph()

    def plothistogram(self, checked):
        if checked:
            self.plothisto = True
        else:
            self.plothisto = False
        if self.multiplot:
            self.update_graph()
        else:
            self.plotall()

        # if self.plothisto:
        # self.histogram_button.setText("histogam off")
        # self.viewHistogamAction.setText("toggle histogam off")
        # else:
        # self.histogram_button.setText("histogam on")
        # self.viewHistogamAction.setText("toggle histogam on")

    def single_trace(self):
        # toggle multiplot
        self.multiplot = not self.multiplot
        if self.multiplot:
            self.multi_button.setText("multi")
            self.update_graph()
        else:
            self.multi_button.setText("single")
            self.plotall()

    def wait_for_scope(self):
        print("External apparatus ready! Triggering now...")
        data = self.sc.readtrace()
        self.alldata.append(data)

    def plotall(self):
        #        self.sc.write(":CHAN1:SCAL 0.001") #LATER WEG
        self.coords = []
        self.mplfig.control_buttons.setVisible(False)
        self.mplfig.ax_plot.clear()
        self.mplfig.ax_hist.clear()
        hdivs = 10  # DHO924S

        if self.sc.connected:
            tel = 0
            while tel < 10:
                # seek a solution in Qt timers
                print(">M>", np.ceil(2 / self.freq))
                sleep(np.ceil(2 / self.freq))  # ?? langzamer dan freq
                self.wait_for_scope()
                tel += 1

            self.ed["scop"]["time"]["scal"] = float(self.sc.query(":TIM:SCAL?"))
            self.ed["scop"]["time"]["offs"] = float(self.sc.query(":TIM:OFFS?"))
            self.ed["scop"]["chan"]["1"]["scal"] = float(self.sc.query(":CHAN1:SCAL?"))
            self.ed["scop"]["chan"]["1"]["offs"] = float(self.sc.query(":CHAN1:OFFS?"))
        scal = self.ed["scop"]["chan"]["1"]["scal"]
        offs = self.ed["scop"]["chan"]["1"]["offs"]
        timescale, timeoffset = self.maketimebase()
        xdivs = np.arange(0, hdivs * 1.01, 1)  # hdivs
        major_xtick = xdivs * timescale
        self.mplfig.ax_plot.set_xticks(major_xtick)  # Grid
        xtrigpos = hdivs * timescale / 2 - timeoffset

        ydivs = np.arange(-4, 4.01, 1)  # to do offset see dho924 programming manual
        print('>n>', scal, offs, ydivs)
        major_ytick = ydivs * scal - offs
        print('>n>', major_ytick, np.min(self.alldata), np.max(self.alldata))
        self.mplfig.ax_plot.plot([xtrigpos, xtrigpos], (major_ytick[0], major_ytick[-1]), linestyle='dotted', )
        self.mplfig.ax_plot.set_yticks(major_ytick)  # Grid
        stamp = self.ed["time"]
        self.mplfig.ax_plot.set(xlabel='time (s)', ylabel='voltage (V)', title=stamp)
        self.mplfig.ax_plot.grid(color='lightgrey', linestyle='-', linewidth=.5)
        self.mplfig.ax_plot.plot(self.tim, np.array(self.alldata[:]).T, '-', markersize=1, alpha=0.5)

        if self.plothisto:
            flatlistlim = list(np.concatenate(np.array(self.alldata).T).flat)  ##is nog geen nparray
            hist, bin_edges = np.histogram(flatlistlim, bins=100)  # default=10
            self.mplfig.ax_hist.hist(x=flatlistlim, bins=bin_edges, color='#0504aa',
                                     alpha=0.19, orientation='horizontal')
            # self.mplfig.ax_hist.set_ylabel('Frequency (Histogram)')
        self.mplfig.canvas.draw()

    def update_graph(self):
        #        self.sc.write(":CHAN1:SCAL 0.001") #LATER WEG
        self.coords = []
        if self.multiplot:
            self.mplfig.control_buttons.setVisible(True)
        else:
            self.mplfig.control_buttons.setVisible(False)
        self.mplfig.ax_plot.clear()
        self.mplfig.ax_hist.clear()
        hdivs = 10
        # beetje onhandig hier. iig een trace
        # todo get rid off nb just use alldata
        if self.sc.connected:
            data = self.sc.readtrace()
            self.alldata = []
            self.alldata.append(data)
            self.ed["scop"]["time"]["scal"] = float(self.sc.query(":TIM:SCAL?"))
            self.ed["scop"]["time"]["offs"] = float(self.sc.query(":TIM:OFFS?"))
            self.ed["scop"]["chan"]["1"]["scal"] = float(self.sc.query(":CHAN1:SCAL?"))
            self.ed["scop"]["chan"]["1"]["offs"] = float(self.sc.query(":CHAN1:OFFS?"))
        scal = self.ed["scop"]["chan"]["1"]["scal"]
        offs = self.ed["scop"]["chan"]["1"]["offs"]
        timescale, timeoffset = self.maketimebase()
        xdivs = np.arange(0, hdivs * 1.01, 1)  # hdivs
        major_xtick = xdivs * timescale
        self.mplfig.ax_plot.set_xticks(major_xtick)  # Grid
        xtrigpos = hdivs * timescale / 2 - timeoffset

        ydivs = np.arange(-4, 4.01, 1)  # to do offset see dho924 programming manual
        major_ytick = ydivs * scal - offs
        ##        self.mplfig.ax_plot.plot([xtrigpos,xtrigpos], (major_ytick[0],major_ytick[-1]) ,linestyle='dotted',)
        self.mplfig.ax_plot.set_yticks(major_ytick)  # Grid
        stamp = self.ed["time"]
        self.mplfig.ax_plot.set(xlabel='time (s)', ylabel='voltage (V)', title=f'{stamp}-{self.dataindex:2d}')
        self.mplfig.ax_plot.grid(color='lightgrey', linestyle='-', linewidth=.5)
        self.mplfig.ax_plot.plot(self.tim, self.alldata[self.dataindex], '-', markersize=1, alpha=0.5)

        if self.plothisto:
            flatlistlim = self.alldata[self.dataindex]  ##is nog geen nparray
            hist, bin_edges = np.histogram(flatlistlim, bins=100)  # default=10
            self.mplfig.ax_hist.hist(x=flatlistlim, bins=bin_edges, color='#0504aa',
                                     alpha=0.19, orientation='horizontal')
            # self.mplfig.ax_hist.set_ylabel('Frequency (Histogram)')
        self.mplfig.canvas.draw()

    def redraw_graph(self):
        # this function has double cde wit update_graph
        self.mplfig.ax_plot.clear()
        self.mplfig.ax_hist.clear()
        self.mplfig.ax_plot.set_title('title tbd on exp level')
        #        self.mplfig.ax.plot(range(len(self.nb)), self.nb, alpha=0.5)
        self.mplfig.ax_plot.plot(self.tim, np.array(self.alldata[:]).T, alpha=0.5)
        self.mplfig.canvas.draw()

    def newFile(self):
        dlg = QMessageBox(self)
        dlg.setWindowTitle("New")
        dlg.setText("Start a new experiment?")
        dlg.setStandardButtons(QMessageBox.Cancel | QMessageBox.Ok)
        dlg.setIcon(QMessageBox.Question)
        button = dlg.exec()
        if button == QMessageBox.Ok:
            print("Yes! todo: close connections and reset logic and all")
        else:
            print("No! fine with me")

    def maketimebase(self):
        timescale = self.ed["scop"]["time"]["scal"]
        timeoffset = self.ed["scop"]["time"]["offs"]
        nrpts = 1000
        hdivs = 10  # on the scope!
        self.tim = np.linspace(0, hdivs * timescale, nrpts, endpoint=True)  ##nrpts+1
        major_xtick = [t for t in self.tim[0:len(self.tim):100]]
        xtrigpos = hdivs * timescale / 2 - timeoffset
        # nrpts= len(np.array(alldata).T)
        return timescale, timeoffset

    def prev_data(self):
        if self.dataindex > 1:
            self.dataindex -= 1
            print('n', self.dataindex)
            self.update_graph()

    def next_data(self):
        # only valid when ...
        if self.dataindex < len(self.alldata):
            self.dataindex += 1
            print('p', self.dataindex)
            self.update_graph()

    def saveAsFile(self):
        # self.on_todo()
        # rename file
        directory = os.getcwd()
        print(">>>", self.olddata)
        filename, _ = QFileDialog.getSaveFileName(directory=directory)
        # self.ed["data"]["data"]= self.alldata
        # self.ed["cmnt"]="10 traces screenshots gemaakt"
        with open(filename, "w") as fp:
            json.dump(self.ed, fp)  # encode dict into JSON

    def saveFile(self):
        print(">>", self.olddata)
        directory = os.getcwd()
        if self.olddata:
            self.statusBar().showMessage("use save as to save existing datafile", 2000)
        else:
            print(self.stamp)
            print(self.ed["time"])
            filename, _ = QFileDialog.getSaveFileName(directory=directory)
            self.ed["data"]["data"] = self.alldata
            self.ed["cmnt"] = "10 traces screenshots gemaakt"
            self.ed["scop"]["*idn"] = self.ident[1]
            with open(filename, "w") as fp:
                json.dump(self.ed, fp)  # encode dict into JSON

    def openFile(self):
        #        filename, _ = QFileDialog().getOpenFileName(directory="C:/Temp")
        directory = os.getcwd()
        filename = directory +"\\testdict20240401_120104.txt"
        # Set the selected file (or file path) to focus on in the file dialog
        if filename:
            with open(filename, 'r') as handle:
                self.ed = json.load(handle)
                # Print the contents of the dictionary
                self.dataindex = 0
                self.alldata = self.ed["data"]["data"]
                self.mplfig.ydata = self.alldata  # check this
                self.ident = self.ed["scop"]["*idn"].split(',')
                self.comment_label.setText(self.ed["cmnt"])
                self.Vin_label.setText("Vin: " + str(self.ed["data"]["Vin"]) + " V")
                self.Rcal_label.setText("Rcal: " + str(self.ed["data"]["Rcal"]) + " Ohm")
                self.olddata = True
                self.Vin_measured = True

                print(len(self.alldata))
                self.plotall()
                # print(json.dumps(self.ed,sort_keys=False, indent=4))
                # text = handle.read()
            # self.textedit.clear()
            # self.textedit.insertPlainText(text)
            # self.textedit.moveCursor(qtg.QTextCursor.Start)
            # self.statusBar().showMessage(f'Editing {filename}')

    def aboutHelp(self):
        screen = app.primaryScreen()
        print('Screen: %s' % screen.name())
        size = screen.size()
        print('Size: %d x %d' % (size.width(), size.height()))
        rect = screen.availableGeometry()
        print('Available: %d x %d' % (rect.width(), rect.height()))
        self.on_todo()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ArduinoGraphApp()
    window.show()
    sys.exit(app.exec())
