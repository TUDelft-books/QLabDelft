# Talk to Rigol DS900 over network or (untested) USB via pyvisa

import sys
import pyvisa  #https://anaconda.org/conda-forge/pyvisa-py
#print(dir(pyvisa.resources.usb.USBInstrument))
import serial
import serial.tools.list_ports

from time import sleep
#from PyQt5.QtCore import QTimer
'''
class dumScope:
    def __init__(self):
        self.msg=["regel0","regel1"]
    def tellme(self,index):
        return self.msg[index]
'''
class Scope(object):
    def __init__(self, parent=None):
        super().__init__()
        # state
        self.connected :bool =False
        self.visa=None
        self.scope=None
        self.speak = None
        self.well=0.100

        self.ser = None

    def find_serial(self):
        # Find available serial devices
        arduino_ports = [
            p.device 
            for p in serial.tools.list_ports.comports()
            if 'Arduino' in p.description  # may need tweaking to match new arduinos
        ]
        usb_devices = []

        try:
            # Try to find USB devices using PyVISA
            rm = pyvisa.ResourceManager()
            reslist = rm.list_resources()
            usb_devices = list(filter(lambda x: 'USB' in x, reslist))
        except pyvisa.errors.VisaIOError:
            print("Failed to find USB devices using PyVISA.")
        
        # Connect to the USB device (e.g., oscilloscope) or Arduino if found
        if usb_devices:
            try:
                self.scope = rm.open_resource(usb_devices[0], timeout=2000) #  timeout=20, chunk_size=1024000)
                self.connected = True
                self.speak = self.scope
                self.scope.write("*RST")
                print("Connected to USB device:", usb_devices[0])
                return
            except pyvisa.errors.VisaIOError:
                print("Failed to connect to USB device:", usb_devices[0])
        
        if arduino_ports:
            print("Connecting to Arduino:", arduino_ports[0])
            try:
                self.ser = serial.Serial(arduino_ports[0], baudrate=115200)
                self.connected = True
                print("Connected to Arduino:", arduino_ports[0])
                return
            except serial.SerialException:
                print("Failed to connect to Arduino:", arduino_ports[0])
        
        # If no devices were found or connection failed
        print("No suitable serial device found.")


# do the connect
    def connect(self):
        rm = pyvisa.ResourceManager()#parameter '@py' krijg ik niet aan de praat
        reslist = rm.list_resources()
        print(reslist)
        usb = list(filter(lambda x: 'USB' in x, reslist))
        try:
            self.scope = rm.open_resource(usb[0], timeout=2000) #  timeout=20, chunk_size=1024000)
            self.connected=True
        except: 
            print("No usb device found, connect to continue")
            self.connected=False
            # sys.exit(1)
        if(self.connected):    
            self.speak=self.scope
            self.scope.write("*RST")

    
#        print("Verbonden met {}".format(self.ident))

    def readtrace(self):
        '''
        function definition to read one trace only works for DHO924
        form='WORD'|'BYTE'|'ASCii'
        100 calls =27 ms (asc) 100 calls = 24 ms (word)
        '''
        self.write(":WAV:FORM ASC")
        rawdata = [float(i) for i in self.query(":WAV:DATA?").split(",")]
        if len(rawdata) == 999:
            rawdata.append(rawdata[-1]) #hack
            print('added one datapoint')
        return rawdata  # ascii to floats

# send a query and return a response
    def query(self,string):
        s=self.scope.query(string)# .rstrip()
        if isinstance(s,str):
            return s[0:len(s)-1]
        else:
            return s

# just send
    def write(self,string):
        callb = self.scope.write(string)#;sleep(self.well)
        return callb

# get ID
    def id(self):
        return self.scope.query("*IDN?")
    
# close
    def close(self):
        self.scope.close()
        self.connected=False
    
if __name__=="__main__":
    # test script
    sc=Scope()
#    sc.connect()
    sc.find_serial()
    print(type(sc))
    print(sc)
    print("here we go again...")
    if sc.connected:
        print(sc.id())
        length = len(sc.readtrace())
        print(length)
#        print(scope.trig_status())
