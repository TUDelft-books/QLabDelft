import sqlite3

# Connect to the database (or create it if it doesn't exist)
connection = sqlite3.connect('text_database.db')
cursor = connection.cursor()

# Create a table to store pages
cursor.execute('''CREATE TABLE IF NOT EXISTS pages (
                    page_number INTEGER PRIMARY KEY,
                    text TEXT NOT NULL
                )''')

# Insert some sample data into the table
sample_data = [
    (1, "This is page 1 text."),
    (2, "This is page 2 text."),
    (3, "This is page 3 text."),
    (4, "This is page 4 text."),
    (5, "This is page 5 text.")
]

cursor.executemany('''INSERT INTO pages (page_number, text) VALUES (?, ?)''', sample_data)

# Commit changes and close the connection
connection.commit()
connection.close()
