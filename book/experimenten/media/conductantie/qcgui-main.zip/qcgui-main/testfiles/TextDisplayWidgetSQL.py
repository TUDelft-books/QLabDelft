import sys
from PyQt5.QtWidgets import QApplication, QWidget, \
    QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextEdit
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt

import sqlite3
#This is the SQL version
class TextDisplayWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()
        self.current_page = 1
        self.db_connection = sqlite3.connect('docs/text_database.db')  # Connect to your SQLite database
        self.cursor = self.db_connection.cursor()
        self.show_page()

    def initUI(self):
        self.layout = QVBoxLayout()
        
        self.text_label = QTextEdit()
        self.text_label.setFont(QFont('Arial', 12))
        self.text_label.setReadOnly(False)
        self.layout.addWidget(self.text_label)

        self.sublayoutWidget = QWidget()
        self.sublayout=QHBoxLayout(self.sublayoutWidget)

        self.prev_button = QPushButton('Previous')
        self.sublayout.addWidget(self.prev_button)

        self.next_button = QPushButton('Next')
        self.sublayout.addWidget(self.next_button)
        self.layout.addWidget(self.sublayoutWidget)

        self.prev_button.clicked.connect(self.prev_page)
        self.next_button.clicked.connect(self.next_page)

        self.setLayout(self.layout)
        self.setWindowTitle('Text Display')

    def show_page(self):
        query = "SELECT text FROM pages WHERE page_number = ?"
        self.cursor.execute(query, (self.current_page,))
        text = self.cursor.fetchone()
        if text:
            self.text_label.setMarkdown(text[0]) #html kan ook
        else:
            self.text_label.setText("Page not found")

    def next_page(self):
        self.current_page += 1
        self.show_page()

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.show_page()

    def jump_to_page(self, page_number):
        query = "SELECT text FROM pages WHERE page_number = ?"
        self.cursor.execute(query, (page_number,))
        text = self.cursor.fetchone()
        if text:
            self.current_page = page_number
            self.show_page()
        else:
            self.text_label.setPlainText("Page not found")

    def closeEvent(self, event):
        self.db_connection.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    widget = TextDisplayWidget()
    widget.setGeometry(100,100,800,800)
    widget.show()
    # Example usage: Jump to page 3
    widget.jump_to_page(3)
 
    sys.exit(app.exec_())
