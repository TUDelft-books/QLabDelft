import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PyQt5.QtWebEngineWidgets  import QWebEngineView
from PyQt5.QtCore import QUrl

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("HTML Content Example")
        self.setGeometry(100, 100, 600, 400)
        self.webview = QWebEngineView()
        self.setCentralWidget(self.webview)
        
        #file_path = r"C:/Users/Henk Buisman/Documents/pyqt5/hello/docs/test.html"
        #file_path = r"C:/Users/Henk Buisman/Documents/pyqt5/hello/docs/twopage.html"
        file_path = r"C:/Users/Henk Buisman/Documents/pyqt5/hello/docs/npages.html"
        #file_path = r"C:/Users/Henk Buisman/Documents/pyqt5/hello/docs/index.html"
        #file_path = "docs/test.html"
        #file_path = r"C:/Users/Henk Buisman/Documents/pyqt5/hello/docs/matjaxnotworkingproperly.html"
        self.webview.load(QUrl.fromLocalFile(file_path))

        # Connect signals and slots
        self.webview.loadFinished.connect(self.on_page_load_finished)

    def on_page_load_finished(self, ok):
        if ok:
            # Page loaded successfully, hide all pages except the first one
            self.webview.page().runJavaScript("show('Page1');")
            # Connect the navigation signal (not used in this version)
            # self.webview.page().urlChanged.connect(self.on_url_changed)
            # Inject MathJax script
            mathjax_loader = """
            var script = document.createElement("script");
            script.type = "text/javascript";
            script.src = "https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-MML-AM_CHTML";
            document.head.appendChild(script);
            """
            self.webview.page().runJavaScript(mathjax_loader)

#    def on_page_load_finished(self, ok):
#        if ok:
#            # Page loaded successfully, execute JavaScript to hide page 2 initially
#            self.webview.page().runJavaScript("document.getElementById('Page2').style.display = 'none';")
#            # Connect the navigation signal
#            self.webview.page().urlChanged.connect(self.on_link_clicked)

#is this still being used??
    def on_url_changed(self, url):
        # Extract the fragment (page id) from the URL
        page_id = url.fragment()
        if page_id in ('Page1', 'Page2'):
            # Execute JavaScript to show/hide the respective page
            self.webview.page().runJavaScript(f"document.getElementById('{page_id}').style.display = 'block';")
            self.webview.page().runJavaScript(f"document.getElementById('{page_id == 'Page1' and 'Page2' or 'Page1'}').style.display = 'none';")

#no longer used
    def on_link_clicked(self, url):
        # Prevent navigation if it's an anchor link
        if url.scheme() == "file":
            # Extract the fragment (page id) from the URL
            page_id = url.fragment()
            # Execute JavaScript to show/hide the respective page
            self.webview.page().runJavaScript(f"document.getElementById('{page_id}').style.display = 'block';")
            self.webview.page().runJavaScript(f"document.getElementById('{page_id == 'Page1' and 'Page2' or 'Page1'}').style.display = 'none';")
        return True

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    #print(sys.path)
    sys.exit(app.exec_())
