import pyvisa
import serial
import serial.tools.list_ports
class serCom(object):
    def __init__(self):
        super().__init__()
#        self.ser = serial.Serial('COM3', 9600)

    def testfind(self):
        ports=serial.tools.list_ports.comports()
        for p in ports:
            print(p)
        print('-------')

    def find_arduino(self):
        arduino_ports = [
            p.device 
            for p in serial.tools.list_ports.comports()
            if 'Arduino' in p.description  # may need tweaking to match new arduinos
            ]
        if not arduino_ports:
            raise IOError("No Arduino found")
        if len(arduino_ports) > 1:
            print(arduino_ports)
            print('Multiple Arduinos found - using the first')
        print(arduino_ports[0])
        self.ser = serial.Serial(arduino_ports[0],baudrate=115200)
        print("connected",self.ser)
#        time.sleep(2)  # Allow some time for the serial connection to initialize

    def find_serial(self):
        # Find available serial devices
        arduino_ports = [
            p.device 
            for p in serial.tools.list_ports.comports()
            if 'Arduino' in p.description  # may need tweaking to match new arduinos
        ]
        usb_devices = []

        try:
            # Try to find USB devices using PyVISA
            rm = pyvisa.ResourceManager()
            reslist = rm.list_resources()
            usb_devices = list(filter(lambda x: 'USB' in x, reslist))
        except pyvisa.errors.VisaIOError:
            print("Failed to find USB devices using PyVISA.")
        
        # Connect to the USB device (e.g., oscilloscope) or Arduino if found
        if usb_devices:
            try:
                self.scope = rm.open_resource(usb_devices[0], timeout=2000) #  timeout=20, chunk_size=1024000)
                self.connected = True
                self.speak = self.scope
                self.scope.write("*RST")
                print("Connected to USB device:", usb_devices[0])
                return
            except pyvisa.errors.VisaIOError:
                print("Failed to connect to USB device:", usb_devices[0])
        
        if arduino_ports:
            print("Connecting to Arduino:", arduino_ports[0])
            try:
                self.ser = serial.Serial(arduino_ports[0], baudrate=115200)
                self.connected = True
                print("Connected to Arduino:", arduino_ports[0])
                return
            except serial.SerialException:
                print("Failed to connect to Arduino:", arduino_ports[0])
        
        # If no devices were found or connection failed
        print("No suitable serial device found.")



    def clear_inbuffer(self):
        # Check if there are bytes in the input buffer
        while self.ser.in_waiting > 0:
            # Read and print all available bytes from the input buffer
            received_data = serc.ser.read(serc.ser.in_waiting).decode().strip()
            print("Received data:", received_data)

    def send_command(self,command):
        self.ser.write(command.encode())
    def receive_response(self):
        response = self.ser.readline().decode().strip()       
        return response
    def receive_sensor_data(self):
        sensor_data = self.ser.readline().decode().strip()
        return sensor_data
    def close(self):
        self.ser.close()

if __name__ == "__main__":
    serc=serCom()
    serc.find_serial()
#    serc.testfind()
#    serc.find_arduino()
#    serc.clear_inbuffer()
    print("====")
    print(serc.receive_response())
    print(serc.receive_response())
    print("====")
    
#    cmdlist = [input("Enter command to send to Arduino (or 'QUIT' to exit): ")]
    cmdlist =["S","G","L","S","Q"]
    cmdlist =["S","S","S","S","G","G","L","l","L","l","G","l","L","S","Q",]
    for cmd in cmdlist :
        serc.send_command(cmd)
        if cmd == "Q":
            serc.close()
            break
        elif cmd == "G":
            sensor_data = serc.receive_sensor_data()
            print("Received sensor data:", sensor_data)
        elif cmd == "S":
            response = ""
            data = []
            for i in range(0,10):
                response = serc.receive_response()
                if i == 0:
                    response = response.lstrip("S: ")
                data.extend(response.split(sep = ","))
            data = [int(_) for _ in data]
            print("Arduino response:", len(data))
        else:
            response = serc.receive_response()
            print(response)

'''
#define SENSOR_PIN A0
//#progam name serial_python
/*reads 1 char and returns strring terminated with enter*/
unsigned long previousMillis = 0;
const unsigned long timeoutInterval = 1000;  // Timeout interval in milliseconds

void info(){
    Serial.print(F("Sketch:   " __FILE__ "\n"
                 "Compiled: " __DATE__ " " __TIME__ "\n\n"));
}

void setup() {
  Serial.begin(115200);
  info();
  digitalWrite(LED_BUILTIN, HIGH);
  delay(200);
  digitalWrite(LED_BUILTIN, LOW);
  delay(200);
  digitalWrite(LED_BUILTIN, HIGH);
  delay(200);
  digitalWrite(LED_BUILTIN, LOW);
  delay(200);
}
void loop() {
    if (Serial.available() > 0) {
      char commandCharacter = Serial.read(); //we use characters (letters) for controlling the switch-case  
      switch (commandCharacter) //based on the command character, we decide what to do
      { 
      case 'I': 
          info();
          break;
      case 'L':
          digitalWrite(LED_BUILTIN, HIGH);
          Serial.println("L");
          break;
      case 'l':
          digitalWrite(LED_BUILTIN, LOW);
          Serial.println("l");
          break;
      case 'G':
          int sensorValue = analogRead(SENSOR_PIN);
          float voltage = sensorValue * (5.0 / 1023.0);
          Serial.print("G: ");
          Serial.println(voltage, 2); // Print voltage with 2 decimal places
          break;
      default:
        Serial.println("Invalid command");
        break;
        }
    }
}
'''