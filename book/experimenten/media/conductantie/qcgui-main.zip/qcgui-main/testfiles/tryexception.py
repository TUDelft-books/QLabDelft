import traceback

try:
    x=3/0
    # Some code that may raise an exception
except Exception as ex:
    msg = ''.join(traceback.TracebackException.from_exception(ex).format())
#    msg = type(ex).__name__

#    print(e)
#    print()
##    print(type(e))
 #   print(type(e).__name__)
    print(msg)
