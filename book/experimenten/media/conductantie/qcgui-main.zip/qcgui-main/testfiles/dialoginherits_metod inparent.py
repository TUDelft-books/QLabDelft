import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QDialog, QVBoxLayout, QPushButton

class ParentWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Parent Window")
        self.setGeometry(100, 100, 400, 300)
        
        self.number = 0
        
        self.button = QPushButton("Open Dialog", self)
        self.button.clicked.connect(self.open_dialog)
    
    def open_dialog(self):
        dialog = DialogWindow(parent=self)
        dialog.exec_()
        
    def update_number(self, new_value):
        self.number = new_value
        print("Updated number in ParentWindow:", self.number)
        
class DialogWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Dialog Window")
        self.setGeometry(200, 200, 300, 200)
        
        layout = QVBoxLayout()
        button = QPushButton("Update Number in Parent", self)
        button.clicked.connect(self.update_parent_number)
        layout.addWidget(button)
        self.setLayout(layout)
        
    def update_parent_number(self):
        new_value = 42  # Example value
        if self.parent():
            self.parent().update_number(new_value)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    parent_window = ParentWindow()
    parent_window.show()
    sys.exit(app.exec_())
