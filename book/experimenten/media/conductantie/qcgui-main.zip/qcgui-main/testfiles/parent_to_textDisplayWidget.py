import warnings #kill depreciation warnin
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QFormLayout, QWidget
from TextDisplayWidgetCSV import TextDisplayWidget
import PyQt5.QtCore as qtc 
#this is a test file. a minigui to test the  SQL an CSV versions of TextDisplayWidget
#suppress DeprecationWarning: sipPyTypeDict() is deprecated, the extension module should use sipPyTypeDictRef() instead
warnings.simplefilter(action='ignore', category=DeprecationWarning)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Main Window')

        # Create the central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Create a layout for the central widget
        layout = QVBoxLayout()
        central_widget.setLayout(layout)

        # Create an instance of TextDisplayWidget and add it to the layout
        text_display_widget = TextDisplayWidget()
        layout.addWidget(text_display_widget)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
