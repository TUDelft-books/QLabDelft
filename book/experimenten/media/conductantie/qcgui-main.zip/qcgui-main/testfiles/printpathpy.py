
import os

#print(dir(os))
#print(os.environ)
#print(os.getenv('PATH'))

def somefunc(y:str, x:int=10)->str:
    print(type(y))
    x += 1
    y += 1
    print(x,y)
    return 45
print(somefunc('sdfsf',44))
print(type(somefunc))