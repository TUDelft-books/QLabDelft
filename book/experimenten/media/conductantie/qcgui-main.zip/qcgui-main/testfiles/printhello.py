msg='hello'
print(msg)