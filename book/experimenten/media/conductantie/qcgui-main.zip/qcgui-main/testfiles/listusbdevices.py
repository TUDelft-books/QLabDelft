import usb.core
def list_usb_devices():
    # Get list of all USB devices
    devices = usb.core.find(find_all=True)

    # Print information about each device
    for device in devices:
        print("Device:")
        print(device)
        print("Vendor ID:", hex(device.idVendor))
        print("Product ID:", hex(device.idProduct))
        print("Serial Number:", device.serial_number)
        print("Manufacturer:", usb.util.get_string(device, device.iManufacturer))
        print("Product:", usb.util.get_string(device, device.iProduct))
        print("")

# Example usage
if __name__ == "__main__":
    list_usb_devices()