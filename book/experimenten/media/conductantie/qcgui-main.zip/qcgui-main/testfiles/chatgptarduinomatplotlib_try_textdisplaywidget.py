import warnings #kill depreciation warnin
import sys
import serial
import serial.tools.list_ports
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtWidgets import QApplication, QMainWindow, \
                QVBoxLayout, QPushButton, QWidget, QLineEdit, QLabel, QAction, QFormLayout, QSlider,QTextEdit
from qtrangeslider import QRangeSlider   #install withpip install qtrangeslider https://pypi.org/project/QtRangeSlider/
import PyQt5.QtCore as qtc 
import random
from scope import Scope  #uit deze directory
from TextDisplayWidgetSQL import TextDisplayWidget
from MatplotlibDisplayWidget import MatplotlibDisplayWidget
#vorige versie chatgptarduinomatplotlib_try_textdisplaywidget.py
#suppress DeprecationWarning: sipPyTypeDict() is deprecated, the extension module should use sipPyTypeDictRef() instead
warnings.simplefilter(action='ignore', category=DeprecationWarning)

class MplCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = plt.figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super().__init__(fig)

class SerCom():
    def __init__(self):
        super().__init__()
    def testfind(self):
        ports=[serial.tools.list_ports.comports()]
        for _ in ports:
            print(_)
        
    def find_arduino(self):
        arduino_ports = [
            p.device 
            for p in serial.tools.list_ports.comports()
            if 'Arduino' in p.description  # may need tweaking to match new arduinos
        ]
        if not arduino_ports:
            raise IOError("No Arduino found")
        if len(arduino_ports) > 1:
            print('Multiple Arduinos found - using the first')
        self.ser = serial.Serial(arduino_ports[0])

#definitie van de functie waarmee je de scoop uitleest

class ArduinoGraphApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        
        self.sc=Scope()
        self.sc.connect()
        if self.sc.connected:
            print(">> >>>",self.sc.id())
        if self.sc.connected:
            self.statusBar().showMessage("connected:"+self.sc.id(),2000)
        else:
            self.statusBar().showMessage('connect scope',2000)

        if False: #adruino connected
            # Initialize serial communication with your Arduino (adjust the port)
            sc=SerCom()
            sc.testfind()
            sc.find_arduino()
            self.statusBar().showMessage(sc.ser.port +" "+ str(sc.ser.baudrate),2000)
        
            print(">> >>"+sc.ser.port +" "+ str(sc.ser.baudrate) )

    #        self.ser = serial.Serial('COM3', baudrate=115200)
        # Initialize data arrays
        self.nb=[]
        self.coords=[]

    def initUI(self):
        self.setWindowTitle("Quantum Conductance")
        self.setGeometry(50, 50, 1800, 900)
        self.init_menu()

        self.central_widget = QWidget(self)
#        self.layout = QVBoxLayout(self.central_widget)

        self.text_display = TextDisplayWidget(self.central_widget)
        self.text_display.setGeometry(qtc.QRect(10, 10, 880, 400))

        self.mplfig = MatplotlibDisplayWidget(self.central_widget)
        self.mplfig.setStyleSheet("background-color: rgb(217, 255, 199);")
        self.mplfig.setGeometry(qtc.QRect(900, 10, 880, 500))

        # Create a label for displaying mouse coordinates
        self.coord_label = QLabel('', self.central_widget)
        self.coord_label.setGeometry(qtc.QRect(200, 450, 300, 300))
        self.mplfig.setStyleSheet("background-color: rgb(117, 155, 199);")

        # Connect the mouse move event to the function
##        self.canvas.mpl_connect('motion_notify_event', self.on_mouse_move)
##        self.canvas.mpl_connect('button_press_event', self.on_mouse_click)
        self.mplfig.canvas.mpl_connect('motion_notify_event', self.on_mouse_move)
        self.mplfig.canvas.mpl_connect('button_press_event', self.on_mouse_click)

        self.layoutWidget = QWidget(self.central_widget)
        self.layoutWidget.setStyleSheet("background-color: rgb(197, 255, 199);")
        self.layoutWidget.setGeometry(qtc.QRect(10, 500, 102, 170))
        self.layoutWidget.setObjectName("layoutWidget")
        self.formLayout = QFormLayout(self.layoutWidget)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setObjectName("formLayout")

        self.update_button = QPushButton("Update Graph", self.layoutWidget)
        self.update_button.setObjectName("UpdateButton")
        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.update_button)
        self.update_button.clicked.connect(self.update_graph)

        self.measure_vin_button = QPushButton("Vin meten", self.layoutWidget)
        self.measure_vin_button.setObjectName("startFun")
        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.measure_vin_button)
        self.measure_vin_button.clicked.connect(self.measure_vin)

        self.start_func_button = QPushButton("Start func", self.layoutWidget)
        self.start_func_button.setObjectName("startFun")
        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.start_func_button)
        self.start_func_button.clicked.connect(self.start_func)

        self.clear_coords_button = QPushButton("Clear points", self.layoutWidget)
        self.clear_coords_button.setObjectName("Clearpoints")
        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.clear_coords_button)
        self.clear_coords_button.clicked.connect(self.clear_coords)

        self.test_scope_button = QPushButton("test scope", self.layoutWidget)
        self.test_scope_button.setObjectName("testScope")
        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.test_scope_button)
        self.test_scope_button.clicked.connect(self.test_scope)

        self.qrange_slider = QRangeSlider(self.central_widget) 
        self.qrange_slider.setGeometry(qtc.QRect(120, 500, 20, 170))
        self.qrange_slider.setOrientation(qtc.Qt.Vertical)
        self.qrange_slider.setBarIsRigid(False)	
        self.qrange_slider.setObjectName("verticalSlider")
        self.qrange_slider.setMinimum(0)
        self.qrange_slider.setMaximum( 1000)
        self.qrange_slider.setSingleStep(1)
        self.qrange_slider.setPageStep(10)
        self.qrange_slider.setValue( (100,900))
        
#        self.qrange_slider.setRange(min=-1., max_=1.)
        self.qrange_slider.valueChanged.connect(self.update_speaker)
        
#        self.qrange_slider.
#        self.layout.addWidget(self.qrange_slider)

        self.horizontalSlider = QSlider(self.central_widget)
        self.horizontalSlider.setGeometry(qtc.QRect(150, 650, 91, 22))
        self.horizontalSlider.setOrientation(qtc.Qt.Horizontal)
        self.horizontalSlider.setMinimum(1)#only accepts ints
        self.horizontalSlider.setMaximum(300)
        self.horizontalSlider.setSingleStep(1)
        self.horizontalSlider.setPageStep(10)
        self.horizontalSlider.setValue(300)
        self.horizontalSlider.setObjectName("horizontalSlider")
        self.horizontalSlider.valueChanged.connect(self.update_speaker)

        self.term_input = QLineEdit('call',self.central_widget)
        self.term_input.setGeometry(qtc.QRect(10, 690, 100, 20))
        self.term_input.editingFinished.connect(self.get_answer)
#        self.layout.addWidget(self.term_input)

        self.label = QLabel("answer here",self.central_widget)
        self.label.setStyleSheet("background-color: rgb(97, 255, 199);")
        self.label.setGeometry(qtc.QRect(10, 720, 91, 22))

        #statusbar
        self.statusBar().showMessage('Welcome',2000)
        self.setCentralWidget(self.central_widget)

    def init_menu(self):
                # Create a menu bar
        menubar = self.menuBar()
        # File menu
        fileMenu = menubar.addMenu('&File')
        # New action
        newAction = QAction('&New', self)
        newAction.setShortcut('Ctrl+N')
        fileMenu.addAction(newAction)

        # Open action
        openAction = QAction('&Open', self)
        openAction.setShortcut('Ctrl+O')
        fileMenu.addAction(openAction)

        # Separator
        fileMenu.addSeparator()

        # Save action
        saveAction = QAction('&Save', self)
        saveAction.setShortcut('Ctrl+S')
        fileMenu.addAction(saveAction)

        # Save As action
        saveAsAction = QAction('&Save As', self)
        fileMenu.addAction(saveAsAction)

        # Separator
        fileMenu.addSeparator()

        # Close action
        closeAction = QAction('&Close', self)
        closeAction.setShortcut('Ctrl+W')
        fileMenu.addAction(closeAction)

        # Exit action
        exitAction = QAction('&Exit', self)
        exitAction.setShortcut('Ctrl+Q')
        exitAction.setStatusTip('Exit application')
        exitAction.triggered.connect(self.close)
        fileMenu.addAction(exitAction)
        # Edit menu
        editMenu = menubar.addMenu('&Edit')
        # View menu
        viewMenu = menubar.addMenu('&View')
        # Help menu
        helpMenu = menubar.addMenu('&Help')
    def on_mouse_move(self, event):
        # Get mouse coordinates and convert to figure coordinates
        if event.inaxes:
            x, y = event.xdata, event.ydata
            self.coord_label.setText(f'Mouse coordinates: x={x:.2f}, y={y:.2f}')
        else:
            self.coord_label.setText('')
    def on_mouse_click(self, event):
        # Get mouse coordinates and convert to figure coordinates
        if event.inaxes:
            x, y = event.xdata, event.ydata
            if event.button == 3:
                self.coord_label.setText(f'Undo coords: x={x:.2e}, y={y:.2e}')
                try:
                    self.coords.pop()
                except IndexError:
                    self.statusBar().showMessage('coordinates list empty ',2000)
                    
            else:
                self.coord_label.setText(f'Mouse clicked at: x={x:.2e}, y={y:.2e}')
                self.coords.append((x, y))
            self.mplfig.ax.scatter(list(zip(*self.coords))[0], list(zip(*self.coords))[1], c='r', linestyle='-')
            self.mplfig.canvas.draw()
        else:
            self.coord_label.setText('')
    def clear_coords(self):
        #clears coordinates and redraws graph
        self.coords=[]
        self.redraw_graph()
    def start_func(self):
        #clears coordinates and redraws graph
        self.sc.write(":SOURce:OUTP:STAT 1")
        #preset scope for the experiment
        self.sc.write(":SOURce:FUNC SIN")
        self.sc.write(":SOURce:VOLT:AMPL 0.5")
        self.sc.write(":SOURce:VOLT:OFFS 0")
        self.sc.write(":SOURce:FREQ 30")
        self.sc.write(":SOURce:OUTP:STAT 1")
        #speak.write(":SOURce:OUTPut:STATe OFF") #AWG off
        self.sc.write(":CHAN2:DISP 1")
        self.sc.write(":CHAN2:SCAL 0.1")
        self.sc.write(":CHAN2:OFFS 0.0")
        #last channel set is active on front panel
        self.sc.write(":CHAN1:DISP 1")
        self.sc.write(":CHAN1:SCAL 0.1")
        self.sc.write(":CHAN1:OFFS 0.0")

        #slow time scale
        #0.05 -> roll mode
        self.sc.write(":TIM:SCAL 0.01")

        #trigger
        self.sc.write(":TRIG:HOLD 0.001")
        #scope.write(":TRIG:LEV 0.0")
        #float(scope.query(":TRIG:HOLD?"))
        #trigger op blauw auto AC
        self.sc.write(":TRIGger:EDGE:SOURce CHANnel2")
        self.sc.write(":TRIGger:COUPling AC")
        self.sc.write(":TRIGger:EDGE:SLOPe NEG")#trigger on negative slope


        self.statusBar().showMessage(f'start function generator')
    def measure_vin(self):
        self.statusBar().showMessage(f'measure vin')
        #stel vertikaal schaal van chanel 1 & 2, set chan1 active
        self.sc.write(":CHAN2:DISP 1")
        self.sc.write(":CHAN1:DISP 1"); #ch1 now active
        self.sc.write(":CHAN2:SCAL 0.5")
        self.sc.write(":CHAN1:SCAL 0.1")
        #start meting Uin
        self.sc.write(":MEAS:ITEM VAVG,CHAN1")
    def test_scope(self):
        #clears coordinates and redraws graph
        self.sc.write(":SOURce:FUNC SIN")
        self.statusBar().showMessage(f'scope function')
    def update_speaker(self):
        mi, ma=self.qrange_slider.value()
        mo = self.horizontalSlider.value()#freq
        mi =(mi-500.)/1000.#recalculate amplitude and offset
        ma =(ma-500.)/1000. #scope wants peakpeak values
        self.statusBar().showMessage(f'speaker changed: {mi}, {ma} freq: {mo}')
        freq =mo/10.
        offs=(mi+ma)/2.     
        amp=(ma-mi)      
        try:
            self.sc.write(":SOUR:VOLT:AMPL " + str(amp))
            self.sc.write(":SOUR:VOLT:OFFS " + str(offs))
            self.sc.write(":SOUR:FREQ " + str(freq))
        except:
            print("VisaIOError")
    def get_answer(self):
        #    term = self.term_input.text()
        #    print(">>>>", term, "<<<<")
        #    ans=.tellme(int(term))
        #    print(ans)
        #    self.label.setText(ans)
        #self.nb=self.sc.readtrace()
        term=self.term_input.text()
        self.statusBar().showMessage(term)
    def update_graph(self):
        #while self.ser.inWaiting() == 0:
        #    pass
        #string_received = self.ser.readline().decode().strip('\r\n')
        #dataArray = string_received.split(" , ")
        self.coords=[]
        if self.sc.connected:
            self.nb=self.sc.readtrace()
        else:
            self.nb= [random.random() for i in range(1000)]
        self.mplfig.ax.clear()
        self.mplfig.ax.plot(range(len(self.nb)), self.nb, alpha=0.5)
        self.mplfig.canvas.draw()

    def redraw_graph(self):
        self.canvas.axes.clear()
        self.canvas.axes.plot(range(len(self.nb)), self.nb, alpha=0.5)
        self.canvas.draw()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    screen = app.primaryScreen()
    print('Screen: %s' % screen.name())
    size = screen.size()
    print('Size: %d x %d' % (size.width(), size.height()))
    rect = screen.availableGeometry()
    print('Available: %d x %d' % (rect.width(), rect.height()))



    window = ArduinoGraphApp()
    window.show()
    sys.exit(app.exec_())