import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from PyQt5.QtWebEngineWidgets import QWebEngineView

class MathJaxTextEdit(QWidget):
    def __init__(self):
        super().__init__()

        self.layout = QVBoxLayout()
        self.webview = QWebEngineView()
        self.layout.addWidget(self.webview)
        self.setLayout(self.layout)

        self.setLaTeXText(r"This is an example of LaTeX in QTextEdit: \(E=mc^2\). You can also use \(\frac{1}{2}\).")

    def setLaTeXText(self, latex_text):
        html = f"""
        <html>
            <head>
                <script type="text/javascript" src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
                <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
            </head>
            <body>
                {latex_text}
            </body>
        </html>
        """
        self.webview.setHtml(html)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('MathJax in QTextEdit')
        self.setGeometry(100, 100, 800, 600)
        self.central_widget = MathJaxTextEdit()
        self.setCentralWidget(self.central_widget)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
