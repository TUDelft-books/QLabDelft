import usb.core

# Define USB vendor and product IDs
VENDOR_ID = 0x1234
PRODUCT_ID = 0x5678

# Function to inspect USB device descriptors
def inspect_usb_device():
    # Find the USB device
    device = usb.core.find(idVendor=VENDOR_ID, idProduct=PRODUCT_ID)
    if device is None:
        raise ValueError("Device not found")

    # Print device descriptors
    print("Device Descriptors:")
    print(device)

    # Print configuration descriptors
    for cfg in device:
        print("\nConfiguration Descriptor:")
        print(cfg)

        # Print interface descriptors
        for intf in cfg:
            print("\nInterface Descriptor:")
            print(intf)

            # Print endpoint descriptors
            for ep in intf:
                print("\nEndpoint Descriptor:")
                print(ep)

# Example usage
if __name__ == "__main__":
    try:
        inspect_usb_device()
    except ValueError as e:
        print("Error:", e)
