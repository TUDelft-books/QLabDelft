import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QSlider, QVBoxLayout, QWidget, QLabel
from PyQt5.QtCore import Qt

from qtrangeslider import QRangeSlider
class RangeSlider(QWidget):
    def __init__(self, min_val=0, max_val=100):
        super().__init__()

        self.min_val = min_val
        self.max_val = max_val

        self.min_slider = QSlider(Qt.Horizontal)
        self.min_slider.setMinimum(self.min_val)
        self.min_slider.setMaximum(self.max_val)
        self.min_slider.setValue(self.min_val)
        self.min_slider.valueChanged.connect(self.update_max_slider)

        self.max_slider = QSlider(Qt.Horizontal)
        self.max_slider.setMinimum(self.min_val)
        self.max_slider.setMaximum(self.max_val)
        self.max_slider.setValue(self.max_val)
        self.max_slider.valueChanged.connect(self.update_min_slider)

        self.range_label = QLabel()
        self.update_range_label()

        layout = QVBoxLayout()
        layout.addWidget(self.min_slider)
        layout.addWidget(self.max_slider)
        layout.addWidget(self.range_label)

        self.setLayout(layout)

               # Change the color of the lower handle
        self.max_slider.setStyleSheet("QSlider::handle:horizontal { background-color: red; }")


    def update_min_slider(self):
        self.min_slider.setValue(min(self.min_slider.value(), self.max_slider.value()))
        self.update_range_label()

    def update_max_slider(self):
        self.max_slider.setValue(max(self.min_slider.value(), self.max_slider.value()))
        self.update_range_label()

    def update_range_label(self):
        self.range_label.setText(f"Selected Range: {self.min_slider.value()} - {self.max_slider.value()}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Range Limiting Slider")
        self.setGeometry(100, 100, 400, 200)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        layout = QVBoxLayout()

        self.range_slider = RangeSlider()
        layout.addWidget(self.range_slider)

        self.qrange_slider = QRangeSlider()
        layout.addWidget(self.qrange_slider)

        self.central_widget.setLayout(layout)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
