import sys
import numpy as np
from PyQt5.QtCore import QTimer
from PyQt5.QtCore import QEvent, Qt
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from circularbufferplot import CircularBufferPlot

class DataGenerator:
    def __init__(self, amplitude=1, noise_level=0.1, points_per_voltage=5):
        self.amplitude = amplitude
        self.noise_level = noise_level
        self.points_per_voltage = points_per_voltage
        self.t = 0
        self.data_counter = 0

    def generate_data_point(self):
        # Generate voltage (v) as a function of time (t) using a sine wave
        
        v = self.amplitude * np.sin(self.t)

        noise = np.random.normal(scale=self.noise_level)
        #noise = np.random.normal(scale=self.noise_level, size=self.points_per_voltage)
        i = v ** 2 + noise
        #i_values = v ** 2 + noise

        if self.data_counter == self.points_per_voltage:
            self.t += 0.1
            self.data_counter = 0
        else:
            self.data_counter += 1
        return v, i
        #return [v] * self.points_per_voltage, i_values
    

        #y = self.amplitude * np.sin(self.t) + noise
        #self.t += 0.1  # Increment time
        #return self.t, y


class PlottingApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Data Plotter")
        self.setGeometry(100, 100, 800, 600)

        self.circular_buffer_plot = CircularBufferPlot()

        layout = QVBoxLayout()
        layout.addWidget(self.circular_buffer_plot)
        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        self.data_generator = DataGenerator(amplitude=1, noise_level=0.2)

        # Install event filter on the main application
        self.installEventFilter(self)

        #self.timer = self.circular_buffer_plot.timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_plot)
        self.timer.start()

    def eventFilter(self, source, event):
        if event.type() == QEvent.KeyPress:
            if event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
                self.circular_buffer_plot.save_average()
        return super().eventFilter(source, event)

    def update_plot(self):
        x, y = self.data_generator.generate_data_point()
        self.circular_buffer_plot.add_data_point(x, y)
        self.circular_buffer_plot.ax.relim()
#        self.circular_buffer_plot.ax.autoscale(enable=True)
        self.circular_buffer_plot.update_plot()
                # After updating the plot, enable autoscaling

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = PlottingApp()
    window.show()
    sys.exit(app.exec_())



