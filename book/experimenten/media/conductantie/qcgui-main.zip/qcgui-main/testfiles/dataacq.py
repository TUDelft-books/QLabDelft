import sys
from PyQt5 import QtWidgets as qtw
#import QApplication, QMainWindow, QPushButton, QLabel

import matplotlib
matplotlib.use('Qt5Agg')  # Use the Qt5Agg backend
#from PyQt5 import QtCore , QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from matplotlib.figure import Figure


class GenerateData(qtw.QMainWindow):
    xdata=[]
    ydata =[]
    def __init(self):
        super().__init__()

    def init_data(self):
        self.xdata=[_ for _ in range(10)]
        self.ydata =[_*_ for _ in range(10)]


class MplCanvas(FigureCanvasQTAgg):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        super().__init__(fig)

class DataAcquisitionApp(qtw.QMainWindow):
    def __init__(self):
        super().__init__()
        self.gd = GenerateData(self)
        
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Data Acquisition App")
        self.setGeometry(100, 100, 700, 400)

        self.label = qtw.QLabel("Press Start to acquire data", self)
        self.label.setGeometry(20, 20, 300, 30)

        self.start_button = qtw.QPushButton("Start", self)
        self.start_button.setGeometry(20, 60, 100, 30)
        self.start_button.clicked.connect(self.start_acquisition)
        self.dataframe = qtw.QFrame()
        self.dataframe.setGeometry(100,100,400,400)

        

        
        # Create the Matplotlib FigureCanvas object
        sc = MplCanvas(self, width=3, height=2, dpi=100)
        sc.axes.plot(self.gd.xdata,self.gd.ydata)  # Example data
        
        self.setCentralWidget(sc)
        self.show()


    def start_acquisition(self):
        # Implement your data acquisition logic here
        # For demonstration purposes, let's print a message
        print("Data acquisition started!")
        self.gd.init_data()
        print(self.gd.ydata)
if __name__ == "__main__":
    app = qtw.QApplication(sys.argv)
    window = DataAcquisitionApp()
    window.show()
    sys.exit(app.exec_())