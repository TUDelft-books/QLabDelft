import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton
from PyQt5.QtCore import Qt
import csv
#THIS IS THE CSV version
class TextDisplayWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()
        self.current_page = 1
        self.load_data()
        self.show_page()

    def initUI(self):
        self.layout = QVBoxLayout()
        
        self.text_label = QLabel()
        self.text_label.setAlignment(Qt.AlignCenter)
        self.text_label.setWordWrap(True)
        self.layout.addWidget(self.text_label)

        self.prev_button = QPushButton('Previous')
        self.prev_button.clicked.connect(self.prev_page)
        self.layout.addWidget(self.prev_button)

        self.next_button = QPushButton('Next')
        self.next_button.clicked.connect(self.next_page)
        self.layout.addWidget(self.next_button)

        self.setLayout(self.layout)
        self.setWindowTitle('Text Display')

    def load_data(self):
        self.data = []
        with open('qc_textdatabase.csv', newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                self.data.append(row)

    def show_page(self):
        page = next((page for page in self.data if int(page['page_number']) == self.current_page), None)
        if page:
            self.text_label.setText(page['text'])
        else:
            self.text_label.setText("Page not found")

    def next_page(self):
        self.current_page += 1
        self.show_page()

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1
            self.show_page()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    widget = TextDisplayWidget()
    widget.show()
    sys.exit(app.exec_())
