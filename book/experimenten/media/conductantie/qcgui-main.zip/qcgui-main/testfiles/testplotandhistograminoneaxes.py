import matplotlib.pyplot as plt
import numpy as np

# Generate some sample data
y = np.random.normal(loc=0, scale=1, size=100)

# Create x-data as the index array
x = np.arange(len(y))

# Create a Matplotlib figure and axes
fig, ax = plt.subplots()

# Plot scatter plot
ax.scatter(x, y, color='blue', label='Scatter Plot')

# Create a secondary y-axis for the histogram
ax_hist = ax.twiny()

# Plot histogram on the secondary y-axis
ax_hist.hist(y, orientation='horizontal', bins=20, alpha=0.5, label='Histogram')

# Set labels and title for scatter plot
ax.set_xlabel('Index')
ax.set_ylabel('Y (Scatter Plot)')
ax.set_title('Scatter Plot with Histogram')

# Set labels and title for histogram
ax_hist.set_ylabel('Frequency (Histogram)')

# Add legend for scatter plot
ax.legend()

# Add legend for histogram
ax_hist.legend()

# Show plot
plt.show()
