import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import numpy as np

class CircularBufferPlot(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Circular Buffer Plot")
        self.setGeometry(100, 100, 800, 600)
        
        self.setup_ui()
        
        # Circular buffer settings
        self.buffer_size = 50
        self.x_buffer = np.full(self.buffer_size, np.nan)
        self.y_buffer = np.full(self.buffer_size, np.nan)
        self.current_index = 0
        
        # Data points settings
        self.saved_averages = []  # List to store saved averages
        
        # Setup matplotlib plot
        self.fig, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.fig)
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_title('Circular Buffer Plot')
        self.ax.set_xlim(0, 1)  # Set x-axis limits
        self.ax.set_ylim(0, 1)  # Set y-axis limits
        self.scatter_buffer = self.ax.scatter([], [], label='Buffer')
        self.scatter_saved = self.ax.scatter([], [], color='red', label='Saved Averages', marker='x')
        self.ax.legend()
        
        # Layout
        layout = QVBoxLayout()
        layout.addWidget(self.canvas)
        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)
        
        # Timer for updating plot
        self.timer = self.fig.canvas.new_timer(interval=100)  # Update every 100ms
        self.timer.add_callback(self.update_plot)
        self.timer.start()
        
    def setup_ui(self):
        pass
        
    def keyPressEvent(self, event):
#        print(event.key() )
#        if event.key() == 32:  # Spacebar
        if event.key() == 16777221:  # enter on keypad
            self.save_average()
    
    def update_plot(self):
        # Plot circular buffer
        self.scatter_buffer.set_offsets(np.column_stack((self.x_buffer, self.y_buffer)))
        
        # Plot saved averages
        if self.saved_averages:
            saved_avgs = np.array(self.saved_averages)  # Convert list to numpy array
            self.scatter_saved.set_offsets(saved_avgs)  # Provide the entire array
        else:
            self.scatter_saved.set_offsets(np.zeros((0, 2)))  # Empty array of shape (0, 2)
        
        # Draw canvas
        self.fig.canvas.draw()
    
    def add_data_point(self, x, y):
        # Update circular buffer
        self.x_buffer[self.current_index] = x
        self.y_buffer[self.current_index] = y
        self.current_index = (self.current_index + 1) % self.buffer_size
    
    def save_average(self):
        if len(self.x_buffer) > 0:
            avg_x = np.nanmean(self.x_buffer)
            avg_y = np.nanmean(self.y_buffer)
            self.saved_averages.append((avg_x, avg_y))
            print(f"Average saved: ({avg_x}, {avg_y})")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = CircularBufferPlot()
    window.show()
    sys.exit(app.exec_())
