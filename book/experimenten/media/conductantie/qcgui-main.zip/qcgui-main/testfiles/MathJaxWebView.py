import sys
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView

class MathJaxWebView(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("MathJax in PyQt5")
        self.setGeometry(100, 100, 800, 600)

        self.webview = QWebEngineView()
        self.setCentralWidget(self.webview)

        self.load_html_with_mathjax()

    def load_html_with_mathjax(self):
        # HTML content with MathJax script and LaTeX equations
        html_content = r"""
        <html>
        <head>
            <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
            <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
        </head>
        <body>
    <h1>MathJax Example</h1>
    <p>Here are some LaTeX equations:</p>
    <ul>
        <li>Inline equation: \( E=mc^2 \)</li>
        <li>Display equation: \[ \frac{1}{2} + \frac{1}{3} = \frac{5}{6} \]</li>
        <li>Equation with Greek letters: \( \alpha+\beta = \gamma \)</li>
        <li>Equation with exponents: \( e^{i\pi} + 1 = 0 \)</li>
        <li>Equation with fractions and square roots: \( \frac{\sqrt{\pi}}{2} \)</li>
        <li>Equation with integrals: \( \int_{0}^{\infty} e^{-x^2} dx = \frac{\sqrt{\pi}}{2} \)</li>
    </ul>
        </body>
        </html>
        """

        # Load HTML content with MathJax into the webview
        self.webview.setHtml(html_content)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MathJaxWebView()
    window.show()
    sys.exit(app.exec_())
