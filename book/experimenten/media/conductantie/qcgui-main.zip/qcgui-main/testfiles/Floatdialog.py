import sys
from PyQt5.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QApplication
from PyQt5.QtCore import QTimer

class FloatDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Float Dialog")
        self.float_value = None
        
        layout = QVBoxLayout()
        self.label = QLabel("Value: ")
        layout.addWidget(self.label)
        
        self.button = QPushButton("Close")
        self.button.clicked.connect(self.close_dialog)
        layout.addWidget(self.button)
        
        self.setLayout(layout)
        
    def set_float_value(self, value):
        self.float_value = value
        self.label.setText("Value: {:.2f}".format(self.float_value))
        
    def close_dialog(self):
        self.accept()

def main():
    app = QApplication(sys.argv)
    float_dialog = FloatDialog()
    float_dialog.show()
    
    def update_float():
        nonlocal value
        float_dialog.set_float_value(value)
        value += 0.1
    
    value = 0.0
    timer = QTimer()
    timer.timeout.connect(update_float)
    timer.start(50)  # Update every 500 milliseconds
    
    app.aboutToQuit.connect(timer.stop)  # Stop timer before quitting
    
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
