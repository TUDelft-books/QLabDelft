import sys
from PyQt6.QtWidgets import QWidget, QVBoxLayout,  QHBoxLayout,QPushButton
from PyQt6.QtCore import pyqtSignal
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import numpy as np

class dataDisplayWidget(QWidget):
    button_pressed = pyqtSignal(str)
    def __init__(self,parent=None):
        super().__init__(parent)
        self.xdata=[]
        self.ydata=[]
        self.current_plot=0
        self.initUI()
    def initUI(self):
        self.layout = QVBoxLayout()
        # Create a matplotlib figure and canvas
        self.fig, self.ax_hist = plt.subplots()
        self.ax_plot = self.ax_hist.twiny()
        self.ax_hist.xaxis.tick_top()
        self.ax_hist.yaxis.tick_left()
        self.ax_plot.xaxis.tick_bottom()
        self.ax_plot.yaxis.tick_right()
        
#        self.ax_plot.spines['left'].set_visible(False)
#        self.ax_plot.spines['top'].set_visible(False)
#        self.ax_plot.spines['right'].set_visible(False)
#        self.ax_plot.spines['bottom'].set_visible(False)
#        self.ax_hist.spines['left'].set_visible(False)
#        self.ax_hist.spines['top'].set_visible(False)
#        self.ax_hist.spines['right'].set_visible(False)
#        self.ax_hist.spines['bottom'].set_visible(False)
        self.canvas = FigureCanvas(self.fig)
        self.layout.addWidget(self.canvas)

        # Create control buttons widget and layout
        self.control_buttons = QWidget()
        self.sublayout = QHBoxLayout(self.control_buttons)
        
        # Create previous and next buttons
        self.prev_button = QPushButton("Previous")
        self.prev_button.clicked.connect(lambda: self.button_pressed.emit("prev"))
        self.sublayout.addWidget(self.prev_button)

        self.next_button = QPushButton('Next')
        self.next_button.clicked.connect(lambda: self.button_pressed.emit("next"))
        self.sublayout.addWidget(self.next_button)

        # Add control buttons widget to the main layout
        self.layout.addWidget(self.control_buttons)

##        # Connect button signals to slots
##        self.prev_button.clicked.connect(self.prev_page)
##        self.next_button.clicked.connect(self.next_page)

        # Set layout for the main widget
        self.setLayout(self.layout)
        self.setWindowTitle('Matplotlib Display')
    def next_page(self, pagnr):
        #use parameters to communicate woth the caller
        if self.current_plot < len(self.ydata)-1:
            self.current_plot += 1
            self.plot_data()
        return self.current_plot   #so that you can use it in another class
    def prev_page(self):
        if self.current_plot > 0:
            self.current_plot -= 1
            self.plot_data()
        return self.current_plot   #so that you can use it in another class

    def testthis(self):
        print('> > >',len(self.ydata), len(np.array(self.ydata).T))
        
#these methodss are never used except for unit tests
        # Initial plot
#        self.plot_data()

    def plot_data(self):
        self.ax_plot.clear()
        self.ax_plot.plot(self.xdata,np.array(self.ydata[self.current_plot]).T,'-', markersize=1, alpha=0.5)
        self.ax_plot.set_title('Sine Wave')
        self.ax_plot.set_xlabel('X')
        self.ax_plot.set_ylabel('Y')
        self.canvas.draw()
    def update_plot(self, x,y):
        # Example of updating the plot
        self.ax.clear()
        self.ax.plot(x, y)
        #self.ax.set_title('Cosine Wave')
        self.canvas.draw()

class speakerDisplayWidget(QWidget):
    button_pressed = pyqtSignal(str)
    def __init__(self,parent=None):
        super().__init__(parent)
        self.xdata=[]
        self.ydata=[]
        self.current_plot=0
        self.initUI()
    def initUI(self):
        self.layout = QVBoxLayout()

        # Create a matplotlib figure and canvas
        self.fig, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.fig)
        self.layout.addWidget(self.canvas)

        # Create control buttons widget and layout
        self.control_buttons = QWidget()
        self.sublayout = QHBoxLayout(self.control_buttons)
        
        # Create previous and next buttons
        self.prev_button = QPushButton("Previous")
        self.prev_button.clicked.connect(lambda: self.button_pressed.emit("prev"))
        self.sublayout.addWidget(self.prev_button)

        self.next_button = QPushButton('Next')
        self.next_button.clicked.connect(lambda: self.button_pressed.emit("next"))
        self.sublayout.addWidget(self.next_button)

        # Add control buttons widget to the main layout
        self.layout.addWidget(self.control_buttons)

##        # Connect button signals to slots
##        self.prev_button.clicked.connect(self.prev_page)
##        self.next_button.clicked.connect(self.next_page)

        # Set layout for the main widget
        self.setLayout(self.layout)
        self.setWindowTitle('Matplotlib Display')
    def next_page(self, pagnr):
        #use parameters to communicate woth the caller
        if self.current_plot < len(self.ydata)-1:
            self.current_plot += 1
            self.plot_data()
        return self.current_plot   #so that you can use it in another class
    def prev_page(self):
        if self.current_plot > 0:
            self.current_plot -= 1
            self.plot_data()
        return self.current_plot   #so that you can use it in another class

    def testthis(self):
        print('> > >',len(self.ydata), len(np.array(self.ydata).T))
        
#these methodss are never used except for unit tests
        # Initial plot
#        self.plot_data()

    def plot_data(self):
        self.ax.clear()
        self.ax.plot(self.xdata,np.array(self.ydata[self.current_plot]).T,'-', markersize=1, alpha=0.5)
        self.ax.set_title('Sine Wave')
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.canvas.draw()
    def update_plot(self, x,y):
        # Example of updating the plot
        self.ax.clear()
        self.ax.plot(x, y)
        #self.ax.set_title('Cosine Wave')
        self.canvas.draw()

class levelsDisplayWidget(QWidget):
    button_pressed = pyqtSignal(str)
    def __init__(self,parent=None):
        super().__init__(parent)
        self.xdata=[]
        self.ydata=[]
        self.current_plot=0
        self.initUI()
    def initUI(self):
        self.layout = QVBoxLayout()

        # Create a matplotlib figure and canvas
        self.fig, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.fig)
        self.layout.addWidget(self.canvas)

        # Create control buttons widget and layout
        self.control_buttons = QWidget()
        self.sublayout = QHBoxLayout(self.control_buttons)
        
        # Create previous and next buttons
        self.prev_button = QPushButton("Previous")
        self.prev_button.clicked.connect(lambda: self.button_pressed.emit("prev"))
        self.sublayout.addWidget(self.prev_button)

        self.next_button = QPushButton('Next')
        self.next_button.clicked.connect(lambda: self.button_pressed.emit("next"))
        self.sublayout.addWidget(self.next_button)

        # Add control buttons widget to the main layout
        self.layout.addWidget(self.control_buttons)

##        # Connect button signals to slots
##        self.prev_button.clicked.connect(self.prev_page)
##        self.next_button.clicked.connect(self.next_page)

        # Set layout for the main widget
        self.setLayout(self.layout)
        self.setWindowTitle('Matplotlib Display')
    def next_page(self, pagnr):
        #use parameters to communicate woth the caller
        if self.current_plot < len(self.ydata)-1:
            self.current_plot += 1
            self.plot_data()
        return self.current_plot   #so that you can use it in another class
    def prev_page(self):
        if self.current_plot > 0:
            self.current_plot -= 1
            self.plot_data()
        return self.current_plot   #so that you can use it in another class

    def testthis(self):
        print('> > >',len(self.ydata), len(np.array(self.ydata).T))
        
#these methodss are never used except for unit tests
        # Initial plot
#        self.plot_data()

    def plot_data(self):
        self.ax.clear()
        self.ax.plot(self.xdata,np.array(self.ydata[self.current_plot]).T,'-', markersize=1, alpha=0.5)
        self.ax.set_title('Sine Wave')
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.canvas.draw()
    def update_plot(self, x,y):
        # Example of updating the plot
        self.ax.clear()
        self.ax.plot(x, y)
        #self.ax.set_title('Cosine Wave')
        self.canvas.draw()

if __name__ == '__main__':
    from PyQt5.QtWidgets import QApplication
    app = QApplication(sys.argv)
    widget = dataDisplayWidget()
    x = np.linspace(0, 10, 100)
    y= []
    for phase in  np.linspace(0,np.pi, 5):
        data = np.sin(x+phase)
        y.append(data)
    #widget.control_buttons.setVisible(True)
    widget.xdata=x #bring data into class
    widget.ydata=y #bring data into class
    widget.testthis()
    widget.plot_data()

    multiplot = True
    if multiplot:
        widget.control_buttons.setVisible(False)
        widget.ax_plot.plot(x,np.array(y).T,'-', markersize=1, alpha=0.5)
    else:
        widget.control_buttons.setVisible(True)
        widget.ax_plot.plot(x,y[0],'-', markersize=1, alpha=0.5)
    widget.show()
    sys.exit(app.exec_())
