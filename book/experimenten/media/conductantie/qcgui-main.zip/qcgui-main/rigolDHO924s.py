import pyvisa
import numpy as np
import warnings

class RigolDHO924S:
    def __init__(self):
        self.usb_rm = pyvisa.ResourceManager()
        self.eth_rm = pyvisa.ResourceManager('@py')
        self.scope = None

    def list_all_resources(self):
        """List all available resources from both USB and Ethernet resource managers."""
        usb_resources = self.usb_rm.list_resources()
        eth_resources = self.eth_rm.list_resources()
        return usb_resources + eth_resources

    def connect_usb(self):
        """Connect to the oscilloscope using the first available USB resource."""
        resources = self.usb_rm.list_resources()
        usb_resource = next((res for res in resources if 'USB' in res or 'usbtmc' in res), None)
        if usb_resource:
            try:
                self.scope = self.usb_rm.open_resource(usb_resource)
                print(f"Connected to USB resource: {usb_resource}")
                #idn = self.scope.query("*IDN?")
                #print(f"Instrument ID: {idn}")
            except Exception as e:
                print(f"Failed to connect to USB resource: {usb_resource}. Error: {e}")
        else:
            print("No USB resources available.")

    def connect_ethernet(self, ip_address):
        """Connect to the oscilloscope using the provided Ethernet IP address."""
        resource = f"TCPIP::{ip_address}::INSTR"
        try:
            self.scope = self.eth_rm.open_resource(resource)
            print(f"Connected to Ethernet resource: {resource}")
            idn = self.scope.query("*IDN?")
            print(f"Instrument ID: {idn}")
        except Exception as e:
            print(f"Failed to connect to Ethernet resource: {resource}. Error: {e}")

    def connect_ethernet_resource(self, resource):
        """Connect to the oscilloscope using the provided Ethernet resource."""
        try:
            self.scope = self.eth_rm.open_resource(resource)
            print(f"Connected to Ethernet resource: {resource}")
            idn = self.scope.query("*IDN?")
            print(f"Instrument ID: {idn}")
        except Exception as e:
            print(f"Failed to connect to Ethernet resource: {resource}. Error: {e}")

    def read_waveform_normal(self, channel=1):
        """Read the waveform in normal mode."""
        if not self.scope:
            raise ValueError("Oscilloscope not connected")
        
        self.scope.write(f':WAV:SOUR CHAN{channel}')
        self.scope.write(':WAV:MODE NORM')
        self.scope.write(':WAV:FORM ASC')

        data = self.scope.query(':WAV:DATA?')
        data = data.replace('\n', '').split(',')

        return np.array(data, dtype=float)

    def read_waveform_raw(self, channel=1):
        """Read the waveform in raw mode."""
        if not self.scope:
            raise ValueError("Oscilloscope not connected")

        # Set the source and mode
        self.scope.write(f':WAV:SOUR CHAN{str(channel)}')
        self.scope.write(':WAV:MODE RAW')
        self.scope.write(":WAV:FORM BYTE")  # WORD ASCII BYTE

        form=self.scope.query(":WAV:FORM?").rstrip()
        print("form=",form)
#        self.scope.write(':WAV:FORM BYTE')
        print("wav mode = ",self.scope.query(':WAV:MODE?'))
        print("memdepth =",self.scope.query(':ACQ:MEMDEPTH?'))

        # Query the raw binary data
        self.scope.write(':WAV:DATA? CHAN1')
#        raw_data = self.scope.query(':WAV:DATA? CHAN1').encode('word')[10:]
#        raw_data = self.scope.query_binary_values(':WAV:DATA?', datatype='B', is_big_endian=True)
#        raw_data = self.scope.read_raw(':WAV:DATA?', datatype='B', is_big_endian=True)

        rawdata =self.scope.read_raw()# terminated by /n???
        hedlen=int(chr(rawdata[1]))
        print('haederlen',hedlen)
        nrpts=int(rawdata[2:2+hedlen])
        idata = np.frombuffer(rawdata, dtype='b',offset=hedlen+2)#        rawdata=scope.read_bytes(count=hdr+nrpts)
#        idata = np.frombuffer(rawdata, dtype='B', count=nrpts,offset=hdr)
        idata = idata * -1 + 255


        print('>>>>',raw_data[:10])

        print(">>",self.scope.query(':SYST:ERR?'))

        # Retrieve the preamble for scaling information
        preamble = self.scope.query(':WAV:PRE?')
        preamble = preamble.split(',')
        points = int(preamble[2])
        y_increment = float(preamble[7])
        y_origin = float(preamble[8])
        y_reference = float(preamble[9])

        # Print preamble for debugging
        print(f"Preamble: {preamble}")
        

        # Query the raw binary data
        self.scope.write(':WAV:DATA?')
        raw_data = self.scope.read_raw()

        print(">>",self.scope.query(':SYST:ERR?'))

        # Print raw data for debugging
        print(f"Raw data length: {len(raw_data)}, {raw_data}")

        # Check if the header indicates zero data points
        if raw_data.startswith(b'#'):
            header_length = int(raw_data[1:2])
            print('HL',header_length)
            expected_length = int(raw_data[2:2 + header_length])
            print(f"Expected data length: {expected_length}")
            
            if expected_length == 0:
                raise ValueError("No data points retrieved. Check the oscilloscope settings.")

        # Strip off the header information
        header_length = 2 + int(raw_data[1])
        raw_data = raw_data[header_length:]

        # Convert the raw data to numpy array
        data = np.frombuffer(raw_data, dtype=np.uint8)

        # Apply scaling to convert to voltage levels
        data = (data - y_reference) * y_increment + y_origin

        return data

    def close(self):
        """Close the connection to the oscilloscope."""
        if self.scope:
            self.scope.close()
            self.scope = None
            print("Connection to oscilloscope closed.")

# Suppress the warning
warnings.filterwarnings("ignore", category=UserWarning)

# Example usage
if __name__ == "__main__":
    scope = RigolDHO924S()

    # List all available resources
    resources = scope.list_all_resources()
#    print(f"Available resources: {resources}")


    # Connect using USB
    scope.connect_usb()

    # Optionally, connect via Ethernet if needed
    ethernet_resource = 'TCPIP::192.168.178.130::INSTR'
    scope.connect_ethernet_resource(ethernet_resource)

    # Read waveform in normal mode (uncomment for testing)
    try:
        normal_waveform = scope.read_waveform_normal(channel=1)
        print(f"Normal waveform len: {len(normal_waveform)}")
        print(f"Normal waveform: {normal_waveform[:5]}")
    except Exception as e:
        print(f"Failed to read waveform. Error: {e}")
    print('------------')

    try:
        raw_waveform = scope.read_waveform_raw(channel=1)
        print(f"Raw waveform: {raw_waveform[:5]}")
    except Exception as e:
        print(f"Failed to read raw waveform. Error: {e}")

    # Close the connection
    scope.close()
