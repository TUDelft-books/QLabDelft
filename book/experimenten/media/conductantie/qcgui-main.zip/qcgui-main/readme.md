## Motivatie
QCGui is een poging om instructies en experiment te combineeren. Goede hardware is of the schelf beschikbaar. Idealiter ontwikkelt zich uit dit progamma een sjabloom dat met mijn beste vriend CHatGPT eenvoudig aan te passen is op een neuw experiemnt.
Zo zal daar natuurijk hoort daar een andere instructies bij horen, maar de placeholder daarvoor zal aanwezig zijn. Evenzo een ander plotje, andere hadrware, andre besturingsknoppen.

Dit idee voor generieke software is niet nieuw. Al sinds de 90er jaren worden op dit niveau engines gemaakt. Echter, met chatgpt komt dit ontwikkelingsprncipe ook onder handberiek van de niet getrainde software ontwikkelaar, een geinteresserde leek

#### platforms
Ik heb alleen windows ervaring, Raspberry pi's (linux) zou ik graag meenemen. Met Aplles heb ik geen ervring 


programmeertaal
python: freeware, go with the mass, LET OP: gebruik 64-bit python
pyqt6
heeft GPL licentie voorwaarden. 

genoeg intro

## file opslag


### De opbouw van de interface

Een main canvas pagina met appliatie menu etc. Ik ken die regels niet, maar wordt automatisch door qt aan voldaan

Bovenaan eem applicatie menu met de nodige defaults.

links een flinke ruimte voor html instructie pagina's.
navigatie knoppen en sliders

Vanuit het experiment kun je pagina's opvragen, of er ook omgekeerd vanuit de pagina's naar een experiment geschakeld moet kunnen worden weet ik niet.

Besturing van het experiment 
Een ruimte waar besturingswidgets staan en 
Indicatoren uit het experiment


Flinke ruimte voor plots. Zovel experimenten zoveel plots
maar een oscilloscoopscherm (Yt) is we het minst


### files op git 
standaard: requirements, readme ..
folder indeling voor python en support files

modules classes
pyserial
resourcesmanager


