import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtCore import QUrl

class HtmlDisplayWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()
        self.current_page = 1

    def initUI(self):
        self.layout = QVBoxLayout()

        # Create a QWebEngineView widget to display HTML content
        self.webview = QWebEngineView()
        self.layout.addWidget(self.webview)

        self.setLayout(self.layout)
        self.setWindowTitle('HTML Display')

        # Load the initial HTML content
        self.load_html()

    def load_html(self):
        # Load the HTML content from a file
        import os
        file_path = os.path.join(os.path.dirname(__file__), 'html', 'npages.html')
        self.webview.load(QUrl.fromLocalFile(file_path))

        # Connect signals and slots
        self.webview.loadFinished.connect(self.on_page_load_finished)

    def on_page_load_finished(self, ok):
        if ok:
            # Page loaded successfully, hide all pages except the first one
            self.webview.page().runJavaScript("show('Page1');")
            # Connect the navigation signal (not used in this version)
            # self.webview.page().urlChanged.connect(self.on_url_changed)
            # Inject MathJax script
            mathjax_loader = """
            var script = document.createElement("script");
            script.type = "text/javascript";
            script.src = "https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-MML-AM_CHTML";
            document.head.appendChild(script);
            """
            self.webview.page().runJavaScript(mathjax_loader)

    def jump_to_page(self, page_number):
        # Call JavaScript function to navigate to a specific page
        js_code = f'navigateToPage({page_number})'
        #js_code = f'navigateFirst()'
        self.webview.page().runJavaScript(js_code)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    widget = HtmlDisplayWidget()
    widget.setGeometry(100, 100, 800, 800)
    widget.jump_to_page(3)
    widget.show()
    # Example usage: Jump to page 3

    sys.exit(app.exec())
