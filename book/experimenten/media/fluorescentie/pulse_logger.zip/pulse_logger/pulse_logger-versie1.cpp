#include <stdio.h>
#include <stdlib.h>
#include <chrono>
#include <thread>
#include <fstream>
#include <vector>
#include "TimeTagger4_interface.h"

const bool USE_CONTINUOUS_MODE = true;
const double DEADTIME_NS = 50.0;
const double THRESHOLD_VOLTAGE = 0.05; // 50 mV
const int MEASUREMENT_DURATION_SECONDS = 60;

std::vector<double> pulse_times;
double last_hit_time = -DEADTIME_NS;
int pulse_count = 0;

void save_to_csv(const std::vector<double>& times, const char* filename) {
    std::ofstream file(filename);
    file << "Time_ns\n";
    for (double t : times) {
        file << t << "\n";
    }
    file.close();
}

timetagger4_device* initialize_timetagger(int buffer_size, int board_id, int card_index) {
    timetagger4_init_parameters params;
    timetagger4_get_default_init_parameters(&params);
    params.buffer_size[0] = buffer_size;
    params.board_id = board_id;
    params.card_index = card_index;

    int error_code;
    const char* err_message;
    timetagger4_device* device = timetagger4_init(&params, &error_code, &err_message);
    if (error_code != CRONO_OK) {
        printf("Init error: %s\n", err_message);
        return nullptr;
    }
    return device;
}

int configure_timetagger(timetagger4_device* device) {
    timetagger4_static_info static_info;
    timetagger4_get_static_info(device, &static_info);

    timetagger4_configuration config;
    timetagger4_get_default_configuration(device, &config);

    config.tdc_mode = TIMETAGGER4_TDC_MODE_CONTINUOUS;

    config.channel[0].enabled = true;
    config.channel[0].start = 0;
    config.channel[0].stop = 0x7FFFFFFF; // 1 minder dan maximaal toegestaan in continuous mode

    config.trigger[TIMETAGGER4_TRIGGER_A].rising = 1;
    config.trigger[TIMETAGGER4_TRIGGER_A].falling = 0;

    config.dc_offset[1] = THRESHOLD_VOLTAGE;

    config.auto_trigger_period = static_info.auto_trigger_ref_clock / 25000;
    config.auto_trigger_random_exponent = 0;

    return timetagger4_configure(device, &config);
}

void process_hits(volatile crono_packet* p, timetagger4_static_info* si, timetagger4_param_info* pi) {
    int hit_count = 2 * p->length;
    if ((p->flags & TIMETAGGER4_PACKET_FLAG_ODD_HITS) != 0) hit_count--;

    uint32_t* packet_data = (uint32_t*)(p->data);
    uint32_t rollover_count = 0;
    uint64_t rollover_period_bins = si->rollover_period;

    for (int i = 0; i < hit_count; i++) {
        uint32_t hit = packet_data[i];
        uint32_t channel = hit & 0xf;
        uint32_t flags = (hit >> 4) & 0xf;

        if ((flags & TIMETAGGER4_HIT_FLAG_TIME_OVERFLOW) != 0) {
            rollover_count++;
        } else if (channel == 0 && (flags & TIMETAGGER4_HIT_FLAG_RISING)) {
            uint32_t ts_offset = (hit >> 8) & 0xffffff;
            double ts_offset_ns = (ts_offset + rollover_count * rollover_period_bins) * pi->binsize / 1000.0;
            double abs_ts_ns = (p->timestamp * pi->packet_binsize) / 1000.0 + ts_offset_ns;

            if (abs_ts_ns - last_hit_time > DEADTIME_NS) {
                pulse_times.push_back(abs_ts_ns);
                last_hit_time = abs_ts_ns;
                pulse_count++;
                printf("Puls %d op %.2f ns\n", pulse_count, abs_ts_ns);
            }
        }
    }
}

int main() {
    timetagger4_device* device = initialize_timetagger(8 * 1024 * 1024, 0, 0);
    if (!device) return 1;

    if (configure_timetagger(device) != CRONO_OK) {
        printf("Configuration failed: %s\n", timetagger4_get_last_error_message(device));
        timetagger4_close(device);
        return 1;
    }

    timetagger4_static_info static_info;
    timetagger4_get_static_info(device, &static_info);

    timetagger4_param_info parinfo;
    timetagger4_get_param_info(device, &parinfo);

    timetagger4_read_in read_config;
    read_config.acknowledge_last_read = 1;
    timetagger4_read_out read_data;

    timetagger4_start_capture(device);

    auto start_time = std::chrono::steady_clock::now();

    while (std::chrono::steady_clock::now() - start_time < std::chrono::seconds(MEASUREMENT_DURATION_SECONDS)) {
        if (timetagger4_read(device, &read_config, &read_data) == CRONO_OK) {
            volatile crono_packet* p = read_data.first_packet;
            while (p <= read_data.last_packet) {
                process_hits(p, &static_info, &parinfo);
                p = crono_next_packet(p);
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    timetagger4_stop_capture(device);
    timetagger4_close(device);

    save_to_csv(pulse_times, "pulse_times.csv");
    printf("Totaal aantal pulsen: %d\n", pulse_count);
    printf("Data opgeslagen in pulse_times.csv\n");

    return 0;
}

