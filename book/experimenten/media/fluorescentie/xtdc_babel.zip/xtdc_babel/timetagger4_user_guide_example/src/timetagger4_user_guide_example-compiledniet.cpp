// pulse_logger.cpp
#include <stdio.h>
#include <stdlib.h>
#include <chrono>
#include <thread>
#include <fstream>
#include <vector>
#include "TimeTagger4_interface.h"

const bool USE_CONTINUOUS_MODE = false;
const bool USE_TIGER_START = true;
const bool USE_TIGER_STOPS = true;
const double DEADTIME_NS = 150.0;
const double THRESHOLD_VOLTAGE = 0.10; // 100 mV
const int MEASUREMENT_DURATION_SECONDS = 60;

std::vector<double> pulse_times;
double last_hit_time = -DEADTIME_NS;

void save_to_csv(const std::vector<double>& times, const char* filename) {
    std::ofstream file(filename);
    file << "Time_ns\n";
    for (double t : times) {
        file << t << "\n";
    }
    file.close();
}

// ... gebruik initialize_timetagger en configure_timetagger zoals in het originele script,
// maar pas configure_timetagger aan:

int configure_timetagger(timetagger4_device* device) {
    timetagger4_static_info static_info;
    timetagger4_get_static_info(device, &static_info);

    timetagger4_configuration config;
    timetagger4_get_default_configuration(device, &config);

    config.channel[0].enabled = true;
    config.channel[0].start = 0;
    config.channel[0].stop = 30000; // ~15 µs

    config.trigger[TIMETAGGER4_TRIGGER_A].rising = 1;
    config.trigger[TIMETAGGER4_TRIGGER_A].falling = 0;

    config.dc_offset[1] = THRESHOLD_VOLTAGE; // kanaal A = index 1

    config.auto_trigger_period = static_info.auto_trigger_ref_clock / 25000;
    config.auto_trigger_random_exponent = 0;

    config.tiger_block[0].enable = USE_TIGER_START ? 1 : 0;
    config.tiger_block[0].start = 0;
    config.tiger_block[0].stop = (int)(12e-9 * static_info.auto_trigger_ref_clock);
    config.tiger_block[0].enable_lemo_output = 1;
    config.tiger_block[0].sources = TIMETAGGER4_TRIGGER_SOURCE_AUTO;
    config.dc_offset[0] = TIMETAGGER4_DC_OFFSET_P_LVCMOS_18;

    config.trigger[TIMETAGGER4_TRIGGER_S].rising = 1;
    config.trigger[TIMETAGGER4_TRIGGER_S].falling = 0;

    return timetagger4_configure(device, &config);
}

// In je packet processing functie:
void process_hits(volatile crono_packet* p, timetagger4_static_info* si, timetagger4_param_info* pi) {
    int hit_count = 2 * p->length;
    if ((p->flags & TIMETAGGER4_PACKET_FLAG_ODD_HITS) != 0) hit_count--;

    uint32_t* packet_data = (uint32_t*)(p->data);
    uint32_t rollover_count = 0;
    uint64_t rollover_period_bins = si->rollover_period;

    for (int i = 0; i < hit_count; i++) {
        uint32_t hit = packet_data[i];
        uint32_t channel = hit & 0xf;
        uint32_t flags = (hit >> 4) & 0xf;

        if ((flags & TIMETAGGER4_HIT_FLAG_TIME_OVERFLOW) != 0) {
            rollover_count++;
        } else if (channel == 0 && (flags & TIMETAGGER4_HIT_FLAG_RISING)) {
            uint32_t ts_offset = (hit >> 8) & 0xffffff;
            double ts_offset_ns = (ts_offset + rollover_count * rollover_period_bins) * pi->binsize / 1000.0;

            if (ts_offset_ns - last_hit_time > DEADTIME_NS) {
                pulse_times.push_back(ts_offset_ns);
                last_hit_time = ts_offset_ns;
            }
        }
    }
}
