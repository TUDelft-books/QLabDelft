#include <stdio.h>
#include <stdlib.h>
#include <chrono>
#include <thread>
#include <fstream>
#include <vector>
#include "TimeTagger4_interface.h"

const bool USE_CONTINUOUS_MODE = true;
const int MEASUREMENT_DURATION_SECONDS = 60;
const double THRESHOLD_VOLTAGE = 0.10; // 100 mV
const double DEADTIME_NS = 150.0;

std::vector<double> pulse_times;

timetagger4_device* initialize_timetagger(int buffer_size, int board_id, int card_index) {
    timetagger4_init_parameters params;
    timetagger4_get_default_init_parameters(&params);
    params.buffer_size[0] = buffer_size;
    params.board_id = board_id;
    params.card_index = card_index;

    int error_code;
    const char* err_message;
    timetagger4_device* device = timetagger4_init(&params, &error_code, &err_message);
    if (error_code != CRONO_OK) {
        printf("Init error: %s\n", err_message);
        return nullptr;
    }
    return device;
}

int configure_timetagger(timetagger4_device* device) {
    timetagger4_configuration config;
    timetagger4_get_default_configuration(device, &config);

    config.tdc_mode = TIMETAGGER4_TDC_MODE_CONTINUOUS;
    config.channel[0].enabled = true;
    config.channel[0].start = 0;
    config.channel[0].stop = 0xffffffff;

    config.trigger[TIMETAGGER4_TRIGGER_A].rising = 1;
    config.trigger[TIMETAGGER4_TRIGGER_A].falling = 0;

    config.dc_offset[1] = THRESHOLD_VOLTAGE; // kanaal A = index 1

    return timetagger4_configure(device, &config);
}

void save_to_csv(const std::vector<double>& times, const char* filename) {
    std::ofstream file(filename);
    file << "Time_ns\n";
    for (double t : times) {
        file << t << "\n";
    }
    file.close();
}

int main() {
    timetagger4_device* device = initialize_timetagger(8 * 1024 * 1024, 0, 0);
    if (!device) return 1;

    if (configure_timetagger(device) != CRONO_OK) {
        printf("Configuration failed.\n");
        timetagger4_close(device);
        return 1;
    }

    timetagger4_param_info parinfo;
    timetagger4_get_param_info(device, &parinfo);
    double binsize_ps = parinfo.packet_binsize;
    double deadtime_bins = DEADTIME_NS * 1000.0 / binsize_ps;

    timetagger4_read_in read_config;
    read_config.acknowledge_last_read = 1;
    timetagger4_read_out read_data;

    timetagger4_start_capture(device);

    auto start_time = std::chrono::steady_clock::now();
    double last_hit_time = -DEADTIME_NS;

    while (std::chrono::steady_clock::now() - start_time < std::chrono::seconds(MEASUREMENT_DURATION_SECONDS)) {
        if (timetagger4_read(device, &read_config, &read_data) == CRONO_OK) {
            volatile crono_packet* p = read_data.first_packet;
            while (p <= read_data.last_packet) {
                uint32_t* packet_data = (uint32_t*)(p->data);
                int hit_count = 2 * p->length;
                if (p->flags & TIMETAGGER4_PACKET_FLAG_ODD_HITS) hit_count--;

                for (int i = 0; i < hit_count; i++) {
                    uint32_t hit = packet_data[i];
                    uint32_t channel = hit & 0xf;
                    uint32_t flags = (hit >> 4) & 0xf;
                    if (channel != 0 || !(flags & TIMETAGGER4_HIT_FLAG_RISING)) continue;

                    uint32_t ts_offset = (hit >> 8) & 0xffffff;
                    double ts_ns = ts_offset * binsize_ps / 1000.0;

                    if (ts_ns - last_hit_time > DEADTIME_NS) {
                        pulse_times.push_back(ts_ns);
                        last_hit_time = ts_ns;
                    }
                }
                p = crono_next_packet(p);
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    timetagger4_stop_capture(device);
    timetagger4_close(device);

    save_to_csv(pulse_times, "pulse_times.csv");
    printf("Data saved to pulse_times.csv\n");

    return 0;
}

